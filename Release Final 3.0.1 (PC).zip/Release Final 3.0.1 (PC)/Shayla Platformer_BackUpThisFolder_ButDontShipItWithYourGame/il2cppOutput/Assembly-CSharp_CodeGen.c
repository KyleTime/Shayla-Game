﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.Void BackgroundHandler::Start()
extern void BackgroundHandler_Start_mB624DC7BB350A4DFA3A728259FD6919001B3A95A (void);
// 0x00000002 System.Void BackgroundHandler::Update()
extern void BackgroundHandler_Update_mAE220C8BD5C3C37766E932910C8677A8FB067DA3 (void);
// 0x00000003 System.Void BackgroundHandler::.ctor()
extern void BackgroundHandler__ctor_m1D2CC73F6EF2E286DB763EAFDA6DE92A78E5CDA1 (void);
// 0x00000004 System.Boolean FadeEffect::get_covering()
extern void FadeEffect_get_covering_m063E5CC30EB59882B3E07BD2854ACEA20230A21A (void);
// 0x00000005 System.Boolean FadeEffect::get_effectTransitioning()
extern void FadeEffect_get_effectTransitioning_mA91FC993B0068B91136148F33F64B345796234D3 (void);
// 0x00000006 System.Void FadeEffect::Start()
extern void FadeEffect_Start_m7F6E600BAACD6D397341686F2177D3E26890C0D8 (void);
// 0x00000007 System.Void FadeEffect::FadeIn()
extern void FadeEffect_FadeIn_m0F544E39C8B9FCD731BDE4B24DA0EB957DAF0BF4 (void);
// 0x00000008 System.Void FadeEffect::FadeOut()
extern void FadeEffect_FadeOut_mA810209AE1BB5C88BD1B8A4D9E98649363097DF8 (void);
// 0x00000009 System.Collections.IEnumerator FadeEffect::MoveTo(UnityEngine.Vector3)
extern void FadeEffect_MoveTo_mFB800729AAD540118C7A5D759C4E84742A24F10A (void);
// 0x0000000A System.Void FadeEffect::.ctor()
extern void FadeEffect__ctor_m060B0A3CA23834F91E3B83C6EBA99B2B758B66A9 (void);
// 0x0000000B System.Void KCutScene::BeginCutScene(CutSceneData)
extern void KCutScene_BeginCutScene_m58C3794AA9DD50F8431017940859807BD10923AF (void);
// 0x0000000C System.Void KCutScene::EndCutScene()
extern void KCutScene_EndCutScene_mF46271833BB768821AD7DD31D71526A07285086C (void);
// 0x0000000D System.Void CutSceneData::BeginCutScene()
// 0x0000000E System.Void CutSceneData::EndCutScene()
// 0x0000000F System.Void CutSceneData::.ctor()
extern void CutSceneData__ctor_m91C2796EDA5CF5506283D05EB02A5E7AADABBD7B (void);
// 0x00000010 System.Boolean KObject::get_timeMove()
extern void KObject_get_timeMove_m17526B1FEDD8FDA0B2E5082F42FB31794DFC278A (void);
// 0x00000011 System.Void KObject::set_timeMove(System.Boolean)
extern void KObject_set_timeMove_m2BC49C9D0F59DCFB5F677EAD5B03D8D0B9A23B39 (void);
// 0x00000012 System.Boolean KObject::get_canFlow()
extern void KObject_get_canFlow_m24A9A414925E31DFC8EF538D0CE68CF2778AD784 (void);
// 0x00000013 System.Void KObject::add_SaveSelves(System.Action)
extern void KObject_add_SaveSelves_m1744837D5F488EF9E3E9D38DF85C5881ADADAAD5 (void);
// 0x00000014 System.Void KObject::remove_SaveSelves(System.Action)
extern void KObject_remove_SaveSelves_mB4F9160504C9912E9D25D7BB5A4C317B003E8258 (void);
// 0x00000015 System.Void KObject::add_LoadSelves(System.Action)
extern void KObject_add_LoadSelves_mD932D7101ECECD186F4F35494D9BADCFB65B99C1 (void);
// 0x00000016 System.Void KObject::remove_LoadSelves(System.Action)
extern void KObject_remove_LoadSelves_mF0896C17AB6DCF1A687791B5982D29DD6E353CBF (void);
// 0x00000017 System.Void KObject::ResetTime()
extern void KObject_ResetTime_m6019E95D7257D06D7D47C1A2D2D311AA5924CA88 (void);
// 0x00000018 System.Void KObject::Start()
extern void KObject_Start_m9B82D20AB4B53D04D3FFD2A1C8CBA013777416A3 (void);
// 0x00000019 System.Void KObject::OnDestroy()
extern void KObject_OnDestroy_mEFC50724B5784333B813F2BB61BD1312FD87A057 (void);
// 0x0000001A System.Void KObject::Update()
extern void KObject_Update_mD8A3CA5719C4832B23CFC224850CE7BED44FDC86 (void);
// 0x0000001B System.Void KObject::LateUpdate()
extern void KObject_LateUpdate_m13B5D45A30CAD51DEBCE6A4974EEF8C8AA4148D5 (void);
// 0x0000001C System.Void KObject::KUpdate()
extern void KObject_KUpdate_mA6ABBF002C94174B8CA42B925DE2598DC34E4D74 (void);
// 0x0000001D System.Void KObject::KLateUpdate()
extern void KObject_KLateUpdate_mF4AE6C9E935CEF1B689B30DD0BC36778DF5212C4 (void);
// 0x0000001E System.Void KObject::KLateUpdateImageEffect()
extern void KObject_KLateUpdateImageEffect_mCE144C599388E69DA3C386EA9B495130E53560B7 (void);
// 0x0000001F System.Void KObject::SaveData()
extern void KObject_SaveData_mF35102A7F6C03A03E1CF62E7183BDFD1361B09FB (void);
// 0x00000020 System.Void KObject::LoadData()
extern void KObject_LoadData_mDCA241EA24D2803A1BD7B9B0587B3332BCA6C99B (void);
// 0x00000021 System.Void KObject::LoadAll()
extern void KObject_LoadAll_m37CD5EB4FEF7D584C6200A9ECEEE454486878775 (void);
// 0x00000022 System.Void KObject::.ctor()
extern void KObject__ctor_m4B75440D34D31FD51FE36D86D911E0D533FE5B4E (void);
// 0x00000023 System.Void KObject::.cctor()
extern void KObject__cctor_m8553FE11E4FB4BBCD92F11E1E46F52731AE48F68 (void);
// 0x00000024 System.Void BackToBase::SelectMethod()
extern void BackToBase_SelectMethod_mB971BBF2535DCE189245CB89F2C55D28495A3C26 (void);
// 0x00000025 System.Void BackToBase::.ctor()
extern void BackToBase__ctor_mF878523827DEEE64C71C3F37A002D64863667A12 (void);
// 0x00000026 System.Void Continue::SelectMethod()
extern void Continue_SelectMethod_m5AF9E05312EBF0B48E9E5B0766583FF7F501ED12 (void);
// 0x00000027 System.Void Continue::.ctor()
extern void Continue__ctor_mB5A1FA33CE2A1D1A1BDCFE942FF6B213F02AD625 (void);
// 0x00000028 System.Void ContinueGame::SelectMethod()
extern void ContinueGame_SelectMethod_m72431D869BA1CE684B630865CE9EEF4AEB054414 (void);
// 0x00000029 System.Void ContinueGame::MenuUpdate()
extern void ContinueGame_MenuUpdate_m8BCEC0DE2377FCAA3581C7A31AF8835807D66839 (void);
// 0x0000002A System.Void ContinueGame::.ctor()
extern void ContinueGame__ctor_m34FD560A24F4EAB815C0057041F6E796ABFDC1A0 (void);
// 0x0000002B System.Void FileSelect::SelectMethod()
extern void FileSelect_SelectMethod_mF430DA2EAB53937222FF07CB78145D28633E06FE (void);
// 0x0000002C System.Void FileSelect::MenuUpdate()
extern void FileSelect_MenuUpdate_m283407DCBCD20D592F0F5E5DF6C0764B9E0228C4 (void);
// 0x0000002D System.Void FileSelect::.ctor()
extern void FileSelect__ctor_m3537E2D5D3226E8A2C4105B7B2D668B51A722713 (void);
// 0x0000002E System.Void FullscreenToggle::SelectMethod()
extern void FullscreenToggle_SelectMethod_m4C9543110AB4DD9731369E925EBF3F9E3837C4A2 (void);
// 0x0000002F System.Void FullscreenToggle::MenuUpdate()
extern void FullscreenToggle_MenuUpdate_mC7C3B2EFECE901B8ECA59DC78CB56F8EF3646C70 (void);
// 0x00000030 System.Void FullscreenToggle::.ctor()
extern void FullscreenToggle__ctor_m76F2F8D97C7288A07671D3E117612C193DBC18E8 (void);
// 0x00000031 System.Void MainMenu::SelectMethod()
extern void MainMenu_SelectMethod_m11F1F7C29C5D9DDFA1F10B5CE494AE7309C337E3 (void);
// 0x00000032 System.Void MainMenu::.ctor()
extern void MainMenu__ctor_m63F945D965550BD614DCD2AE7F7489D4F28C5B30 (void);
// 0x00000033 System.Void NewGame::SelectMethod()
extern void NewGame_SelectMethod_m8E5646A7169E77E327562F7DE3E0A2EBA2D5839A (void);
// 0x00000034 System.Void NewGame::.ctor()
extern void NewGame__ctor_mEEFA222781A9319B278E4A7BAF3BBE1DD124B8BA (void);
// 0x00000035 System.Void Options::SelectMethod()
extern void Options_SelectMethod_m5957E324D9AA133756D930201E0828DE95F2ECDA (void);
// 0x00000036 System.Void Options::.ctor()
extern void Options__ctor_mAE411B1BD3EA4C02BE8C21D8A7C7141302425063 (void);
// 0x00000037 System.Void Quit::SelectMethod()
extern void Quit_SelectMethod_m76E38C22A6232B7235DBA581900FAADC1BBAF0C5 (void);
// 0x00000038 System.Void Quit::.ctor()
extern void Quit__ctor_m4C50BF52D3A6ADB583BE76FE1DEAFB1C889B3F6A (void);
// 0x00000039 System.Void Retry::SelectMethod()
extern void Retry_SelectMethod_mDD597DE04CABAF2EA37178F32F932F269EDD3F02 (void);
// 0x0000003A System.Void Retry::MenuUpdate()
extern void Retry_MenuUpdate_mEBBDF4251F4AE19ADF43183BB87F7FDCF585E69B (void);
// 0x0000003B System.Void Retry::.ctor()
extern void Retry__ctor_m3DB641DAFC3773EFF214851FF19378A9ED013851 (void);
// 0x0000003C System.Void SfxChange::SelectMethod()
extern void SfxChange_SelectMethod_m0973307A068C4366324117D2B75918AF61DA0932 (void);
// 0x0000003D System.Void SfxChange::MenuUpdate()
extern void SfxChange_MenuUpdate_m3FBDA6709074319DF6ABCB72C4A7ABAA10D3C56F (void);
// 0x0000003E System.Void SfxChange::.ctor()
extern void SfxChange__ctor_m787160AD88200AE25BF62BD05EA6D3B477BB123A (void);
// 0x0000003F System.Void SpeedrunToggle::SelectMethod()
extern void SpeedrunToggle_SelectMethod_m075FB8C052A051CFEAD13CDB4C320AC7D806A24E (void);
// 0x00000040 System.Void SpeedrunToggle::MenuUpdate()
extern void SpeedrunToggle_MenuUpdate_m6A4D59E3C7DD5306558FB2A9C43745362B50ED4B (void);
// 0x00000041 System.Void SpeedrunToggle::.ctor()
extern void SpeedrunToggle__ctor_m882D88FF5D848401A57F51C4A057309563C59435 (void);
// 0x00000042 UnityEngine.Transform[] PauseMenu::get_menuObjects()
extern void PauseMenu_get_menuObjects_mC12ACC7B71C930CF29812288373FD01490113D48 (void);
// 0x00000043 System.Void PauseMenu::Start()
extern void PauseMenu_Start_m4DE86B520C58E4A1F4C1E44C229DF6A66D3C7615 (void);
// 0x00000044 System.Void PauseMenu::ResetMethodArray()
extern void PauseMenu_ResetMethodArray_m7ADB3E968655B9526C7850CF9AC62F606079BF20 (void);
// 0x00000045 System.Void PauseMenu::Update()
extern void PauseMenu_Update_m66A1E2D2A45F922DFF88D7DAD26E1833593EAECD (void);
// 0x00000046 System.Void PauseMenu::FlipFlop()
extern void PauseMenu_FlipFlop_m6BDA6FF7B0650726FA85135B98DBE63E891EF75F (void);
// 0x00000047 System.Void PauseMenu::UpdatePause()
extern void PauseMenu_UpdatePause_m8AC33F9A757E21AA7812D1FE32ADA472335ACE88 (void);
// 0x00000048 System.Void PauseMenu::ActivatePause()
extern void PauseMenu_ActivatePause_m62631E7D27FFBA73CBF69C4A8C8C654089C001BA (void);
// 0x00000049 System.Void PauseMenu::DeactivatePause()
extern void PauseMenu_DeactivatePause_mFE201F1C0057823F14C485AF38BF1AD6C849611E (void);
// 0x0000004A System.Void PauseMenu::UpdateMenu()
extern void PauseMenu_UpdateMenu_m3B93426326F6186D271DE794D66D7677A33AB88B (void);
// 0x0000004B System.Void PauseMenu::FigureOutSelectedOption()
extern void PauseMenu_FigureOutSelectedOption_m4DC5E9B44E9D27BEA900131E64B4A188F94DB311 (void);
// 0x0000004C System.Void PauseMenu::ShowSelected()
extern void PauseMenu_ShowSelected_mD49A1F15FE8BB05884324EF557B638D1A281CE75 (void);
// 0x0000004D System.Void PauseMenu::HandleSelect()
extern void PauseMenu_HandleSelect_mC301FBBCB1E5AA413FA33010DB82E42B3492D6AA (void);
// 0x0000004E System.Int32 PauseMenu::GetIndexOfMethod(PauseMenuMethod)
extern void PauseMenu_GetIndexOfMethod_m2FB9AE458B66FEDB0A87F0978459E2490180E279 (void);
// 0x0000004F System.Void PauseMenu::.ctor()
extern void PauseMenu__ctor_m160C6A78E24C65136139628D4BC77D89D26EC373 (void);
// 0x00000050 System.Void PauseMenuMethod::SelectMethod()
// 0x00000051 System.Void PauseMenuMethod::MenuUpdate()
extern void PauseMenuMethod_MenuUpdate_m8F3079902D68739066DC1D0100E21E82DD84AE62 (void);
// 0x00000052 System.Void PauseMenuMethod::.ctor()
extern void PauseMenuMethod__ctor_mF65068BAB2063030419904BD7113202304103B1D (void);
// 0x00000053 System.Void RoomSystem::Start()
extern void RoomSystem_Start_m210B4BE4D67163EAFCCB2DE797A8AB644A5C4799 (void);
// 0x00000054 System.Void RoomSystem::OnDrawGizmosSelected()
extern void RoomSystem_OnDrawGizmosSelected_mA8D6170EBC4E4A6597BFC81884CC979AA0F1E803 (void);
// 0x00000055 System.Void RoomSystem::UpdateCameraSize()
extern void RoomSystem_UpdateCameraSize_mAE007A94A8360470F72F343643BA2FCB85037BDB (void);
// 0x00000056 System.Void RoomSystem::Update()
extern void RoomSystem_Update_m122BAEFBDF3324BA0663BBC8D85A3A5C2357795D (void);
// 0x00000057 System.Void RoomSystem::ChoccyMilkMakePainGoAway()
extern void RoomSystem_ChoccyMilkMakePainGoAway_mF0AAA2BC7084DDC37D23D3876D597EA40FA04612 (void);
// 0x00000058 System.Void RoomSystem::CheckRoomChange()
extern void RoomSystem_CheckRoomChange_m353C3041E9FF60F13766FF26B772B2E97A05397E (void);
// 0x00000059 UnityEngine.Vector2 RoomSystem::GetRoomPos(System.Int32)
extern void RoomSystem_GetRoomPos_m77A542D6EA38CCD3BCA5AB60779B31F2042C3480 (void);
// 0x0000005A UnityEngine.Vector2 RoomSystem::GetRoomSize(System.Int32)
extern void RoomSystem_GetRoomSize_mA046E63DC6AEE7F456E6F4E019CE23C8DE281280 (void);
// 0x0000005B UnityEngine.Vector2 RoomSystem::GetSpawnPoint(System.Int32,System.Int32)
extern void RoomSystem_GetSpawnPoint_mC306D993617E71105FB40A469A265A4311435A35 (void);
// 0x0000005C System.Boolean RoomSystem::InsideRoom(System.Int32)
extern void RoomSystem_InsideRoom_m5EE537DE34D8481F0C29CF8FBDD0021E912469FF (void);
// 0x0000005D System.Boolean RoomSystem::InsideRoom(UnityEngine.Vector3,System.Int32)
extern void RoomSystem_InsideRoom_m5CDD84CB902BE340AC6BBC017DBB09D8CC135A16 (void);
// 0x0000005E System.Void RoomSystem::LoadRoom(System.Int32)
extern void RoomSystem_LoadRoom_m7F846900CBD98147DEC6F1F80614812394343BBC (void);
// 0x0000005F System.Void RoomSystem::RecheckSpawn()
extern void RoomSystem_RecheckSpawn_mF113974EB2FDE0EC7B54A26BF38A475A0D333AC7 (void);
// 0x00000060 UnityEngine.Vector2 RoomSystem::CalculatePosInRoom()
extern void RoomSystem_CalculatePosInRoom_m5B749C6E154525E86A7C217B33B8202F2D27B852 (void);
// 0x00000061 System.Collections.IEnumerator RoomSystem::FreezeTime()
extern void RoomSystem_FreezeTime_m3FFBFDD448E56E08249184DA59D220473CEC9E21 (void);
// 0x00000062 System.Void RoomSystem::OnDrawGizmos()
extern void RoomSystem_OnDrawGizmos_mBBBC542085C787B2F18744FCBCFDD701D4DC46D3 (void);
// 0x00000063 System.Void RoomSystem::.ctor()
extern void RoomSystem__ctor_mE32E2689C4BC191E23575C53F63D8D19924CFDD7 (void);
// 0x00000064 System.Void Room::.ctor(UnityEngine.Vector2,System.Int32)
extern void Room__ctor_mEA60D98B399503A3A290AD7A45218ABAA0B62723 (void);
// 0x00000065 System.Boolean HandleSpeedrunTimer::get_displayTimer()
extern void HandleSpeedrunTimer_get_displayTimer_m17F5AF6A0394031B96B9CCD51629CA7AE316FBFF (void);
// 0x00000066 System.Void HandleSpeedrunTimer::set_displayTimer(System.Boolean)
extern void HandleSpeedrunTimer_set_displayTimer_m9D1275434F475E6F4657B5CC21EC9391EEE2C9F9 (void);
// 0x00000067 System.Void HandleSpeedrunTimer::set_timerTime(System.Single)
extern void HandleSpeedrunTimer_set_timerTime_m1DA1CAE2421478AADFE7BDBE59027BD154C056C1 (void);
// 0x00000068 System.Single HandleSpeedrunTimer::get_timerTime()
extern void HandleSpeedrunTimer_get_timerTime_mA03EED55589DCD115124E912F7CB2C56C2DD4B89 (void);
// 0x00000069 System.Void HandleSpeedrunTimer::Awake()
extern void HandleSpeedrunTimer_Awake_m39B2B5F412537FAC509CD36455CBB18E448E89C8 (void);
// 0x0000006A System.Void HandleSpeedrunTimer::Update()
extern void HandleSpeedrunTimer_Update_m6DD8847A20B87B274614636AFC0797D3B8495EC5 (void);
// 0x0000006B System.String HandleSpeedrunTimer::FloatAsTime(System.Single)
extern void HandleSpeedrunTimer_FloatAsTime_m2FDC202DDB711705BE4369687F60374B138735C6 (void);
// 0x0000006C System.Void HandleSpeedrunTimer::.ctor()
extern void HandleSpeedrunTimer__ctor_mFDBC8417B9F4C18955F5228A3F849D4888C58BD0 (void);
// 0x0000006D System.Void Chapter1Cutscene::BeginCutScene()
extern void Chapter1Cutscene_BeginCutScene_mB87A267DFE119B7D85F113CFDD8E562B52B8DB7F (void);
// 0x0000006E System.Void Chapter1Cutscene::EndCutScene()
extern void Chapter1Cutscene_EndCutScene_mA7F5773F8C932F64A54C268AD443E8A148368FC2 (void);
// 0x0000006F System.Void Chapter1Cutscene::.ctor()
extern void Chapter1Cutscene__ctor_m0DDCB54A90A4851683FF8D50D662E688E09B5B84 (void);
// 0x00000070 System.Void Chapter1Intro::Awake()
extern void Chapter1Intro_Awake_m8FD093BC0CD13B1A381577E90AF949E99526BB32 (void);
// 0x00000071 System.Void Chapter1Intro::Update()
extern void Chapter1Intro_Update_m39E3E811966F40FECDCED22B62CB08A93F2989B4 (void);
// 0x00000072 System.Collections.IEnumerator Chapter1Intro::AAAAAAAA()
extern void Chapter1Intro_AAAAAAAA_mEF498C850AE0F647E98CD2893273DD1465F68C08 (void);
// 0x00000073 System.Void Chapter1Intro::DestroyTheThing()
extern void Chapter1Intro_DestroyTheThing_m2BC7D4F3A241A208B57ED15454412B6EE1745D74 (void);
// 0x00000074 System.Void Chapter1Intro::.ctor()
extern void Chapter1Intro__ctor_m021939BBE9ACDF5A09F3E4D2BAF60395C88E1C93 (void);
// 0x00000075 System.Void NoiseColor::Start()
extern void NoiseColor_Start_m5214161A77E15416A29FAADFE9674CE6D5E4CAE5 (void);
// 0x00000076 System.Void NoiseColor::Update()
extern void NoiseColor_Update_m22EF5CB1CF5C36924AB61D1C687C11582FC8B6C3 (void);
// 0x00000077 System.Void NoiseColor::FunnyEffect()
extern void NoiseColor_FunnyEffect_m63992ED64687CCCDB8572AA8346480A565C61579 (void);
// 0x00000078 UnityEngine.Color NoiseColor::ApplyColorTransform(UnityEngine.Color,UnityEngine.Color,System.Int32,System.Int32,System.Single,System.Int32,System.Int32,UnityEngine.Vector2)
extern void NoiseColor_ApplyColorTransform_m71BFB6281D4DE64C03B3167F590C98742C416B3E (void);
// 0x00000079 System.Void NoiseColor::.ctor()
extern void NoiseColor__ctor_m322A15548EBD28EB7994609630B3E02F5E47CD7E (void);
// 0x0000007A CollectableData Collectables::get_curData()
extern void Collectables_get_curData_m989355BEF6AD9EFFEA02A9C48067F646881618A1 (void);
// 0x0000007B System.Void Collectables::InitializeCollectableData()
extern void Collectables_InitializeCollectableData_m008FEBB94A5567F050FCFBEEBC081D8483C0E9BA (void);
// 0x0000007C System.Void Collectables::CollectedMarble(System.Int32)
extern void Collectables_CollectedMarble_m35DB467102E081C98E6C08A27C8B4B8A3A10AEC3 (void);
// 0x0000007D System.Void Collectables::SaveCollectables()
extern void Collectables_SaveCollectables_m46A5324A7C9A0CF7299B949C41BADEC8EC3D536E (void);
// 0x0000007E System.Void Collectables::LoadCollectables()
extern void Collectables_LoadCollectables_mB54CDA291E66018CEB183F6CB58B53F769006695 (void);
// 0x0000007F System.Int32 Collectables::Total()
extern void Collectables_Total_m8EC36A225CF7C6AE9485B36ED9001019AE58FB1F (void);
// 0x00000080 System.Int32 Collectables::MaxPossible()
extern void Collectables_MaxPossible_m9BFEA16A274A13E06A1D13C136099896DB683E72 (void);
// 0x00000081 System.Void Collectables::.cctor()
extern void Collectables__cctor_mD3AC459524534DE88304580AE1DB47722944F4D1 (void);
// 0x00000082 System.Void CollectableData::.ctor()
extern void CollectableData__ctor_m3B6B1EAA9C9DA03DF5A17D10E873FBFDF6D604D5 (void);
// 0x00000083 System.Void MarbleCollectable::Awake()
extern void MarbleCollectable_Awake_m4322C98116E26C200D12147010E743602E35F8E3 (void);
// 0x00000084 System.Collections.IEnumerator MarbleCollectable::WaitForRoomSystem()
extern void MarbleCollectable_WaitForRoomSystem_mD43B61B4C7F073A5AA5EA657F6942FB2E2C97E17 (void);
// 0x00000085 System.Void MarbleCollectable::KUpdate()
extern void MarbleCollectable_KUpdate_m91A53FB9601D392FDD8087F6BED355E8ECC4A222 (void);
// 0x00000086 System.Collections.IEnumerator MarbleCollectable::Follow()
extern void MarbleCollectable_Follow_mA5890AC7DE41EED969F259A8039923B79FF86281 (void);
// 0x00000087 System.Void MarbleCollectable::add_CallCollection(System.Action)
extern void MarbleCollectable_add_CallCollection_mBBF47C12A7C8D4EFB5127DB00E5D429B9A455C89 (void);
// 0x00000088 System.Void MarbleCollectable::remove_CallCollection(System.Action)
extern void MarbleCollectable_remove_CallCollection_mE330BBF907327E0003FCE317AA149792F1808781 (void);
// 0x00000089 System.Void MarbleCollectable::InvokeCallCollect()
extern void MarbleCollectable_InvokeCallCollect_m36ABFC34D6B2ECA9CD090B40000E1E8D6F68A602 (void);
// 0x0000008A System.Void MarbleCollectable::CollectCurrent()
extern void MarbleCollectable_CollectCurrent_mF440FE839D4C07510160122980E9E2617F144560 (void);
// 0x0000008B System.Void MarbleCollectable::LoadData()
extern void MarbleCollectable_LoadData_m6733A5A8814264E7C011C39FFE7EAB94EB548A74 (void);
// 0x0000008C System.Void MarbleCollectable::SaveData()
extern void MarbleCollectable_SaveData_m3DE01AE9751AF7105587AE619579018A151F9452 (void);
// 0x0000008D System.Boolean MarbleCollectable::InArea(UnityEngine.Vector2)
extern void MarbleCollectable_InArea_m8C97F9406A01C2114C3921E3CA5850F6243D59CE (void);
// 0x0000008E System.Void MarbleCollectable::Collect()
extern void MarbleCollectable_Collect_m5488109030B247559467E18B199AEFC10F967AE5 (void);
// 0x0000008F System.Void MarbleCollectable::ParticleSystemActivate()
extern void MarbleCollectable_ParticleSystemActivate_mDDC4C85160EF558D11B367BC193CB110918F8760 (void);
// 0x00000090 System.Collections.IEnumerator MarbleCollectable::CheckDelete()
extern void MarbleCollectable_CheckDelete_mE602DADDFC93893DE1D822D84D256A5F8B5AD2B0 (void);
// 0x00000091 System.Void MarbleCollectable::OnDrawGizmosSelected()
extern void MarbleCollectable_OnDrawGizmosSelected_m268F18079FF295DC79078B26AB34ADBFE6988E37 (void);
// 0x00000092 System.Void MarbleCollectable::.ctor()
extern void MarbleCollectable__ctor_m2E0ECF274902B986089248300441D3DFF5E536C1 (void);
// 0x00000093 System.Void MarbleCollectable::.cctor()
extern void MarbleCollectable__cctor_m77D6958CE8B2083123388B0A0A007F2BE2EFA297 (void);
// 0x00000094 System.Int32 Core::get_numberOfChapters()
extern void Core_get_numberOfChapters_m9E7ECBD732C447C16D12BC5508259D26107529CC (void);
// 0x00000095 System.Void Core::SaveGame()
extern void Core_SaveGame_mEE55B36842F812E0EF2B814A82F06BA05AD6E53D (void);
// 0x00000096 System.Void Core::LoadGame(System.Boolean)
extern void Core_LoadGame_mDB13F76371EA79E243A3662565D18C8484598D66 (void);
// 0x00000097 System.Void Core::DeleteData()
extern void Core_DeleteData_m9220A3CAD2BB00C87B62829946AD70EA79F82F0A (void);
// 0x00000098 System.Void Core::ContinueGame()
extern void Core_ContinueGame_m83B79DAFF85F2B47C3468EB99160D1F847E68A5B (void);
// 0x00000099 System.Void Core::.cctor()
extern void Core__cctor_m3669FF895D2A35C5DA5E3F0E32B7C505F012006D (void);
// 0x0000009A ProgressData Progress::get_curFile()
extern void Progress_get_curFile_m83153598BAA8ECE7C0453B8C8C8443308F74525C (void);
// 0x0000009B System.Void Progress::set_curFile(ProgressData)
extern void Progress_set_curFile_mFD6F938A6618FF32667258F3A6EC873336B6D743 (void);
// 0x0000009C System.Collections.IEnumerator Progress::FadeIntoNextChapter(System.Int32)
extern void Progress_FadeIntoNextChapter_m6C255F321F36A34BD50F089736B9BD3B77AEC761 (void);
// 0x0000009D System.Void Progress::LoadIntoChapter(System.Int32)
extern void Progress_LoadIntoChapter_m0E77CE9DFA54A735CE15C2EE58581FE916631725 (void);
// 0x0000009E System.Void Progress::SetPlayerToPosition()
extern void Progress_SetPlayerToPosition_m63ECDA3D3535C364316C2D05EDF5C539CF3B96BC (void);
// 0x0000009F System.Void Progress::UpdateProgress()
extern void Progress_UpdateProgress_m46F12E7B12ADFE34E04ADC4B2136AABEC48020FB (void);
// 0x000000A0 System.Void Progress::SavePlayerProgress()
extern void Progress_SavePlayerProgress_m9609F0F1558779308DFF65A71FA44A0D77D89A2A (void);
// 0x000000A1 System.Void Progress::LoadPlayerProgress()
extern void Progress_LoadPlayerProgress_m4DC27533395C099F778472C74D2C306078E3E47F (void);
// 0x000000A2 System.Void Progress::.cctor()
extern void Progress__cctor_m4B4CA8CA3355F80435F6E2733BCEF4E4F2790022 (void);
// 0x000000A3 System.Void ProgressData::.ctor()
extern void ProgressData__ctor_m953F5DC1E5F55E74F23E1BE58189BEA080AFE826 (void);
// 0x000000A4 System.Void DisplayFile::Start()
extern void DisplayFile_Start_mA70503AE39AB94F3C1F3245AEDB52D489642D2DB (void);
// 0x000000A5 System.Void DisplayFile::Update()
extern void DisplayFile_Update_m5090A6E8AD6B0ADDFFB767FD04BAC710E1F06149 (void);
// 0x000000A6 System.Void DisplayFile::.ctor()
extern void DisplayFile__ctor_m6E800B95186C9A6F4AF546799D579CA8FA73F04E (void);
// 0x000000A7 System.Void End::Awake()
extern void End_Awake_mD9547194F4FFC0162518B16BB06F97BDC47E61D2 (void);
// 0x000000A8 System.Void End::OnTriggerEnter2D(UnityEngine.Collider2D)
extern void End_OnTriggerEnter2D_m526D1F2CD041D3AE529D54FA22AAF1E2ADE734D1 (void);
// 0x000000A9 System.Void End::.ctor()
extern void End__ctor_m7507A3404C1C1C5401FFB8303216E5ABA4263169 (void);
// 0x000000AA System.Void EndCutscene::BeginCutScene()
extern void EndCutscene_BeginCutScene_m17F83A2F7153FF636162C0B4944567290040F1B7 (void);
// 0x000000AB System.Void EndCutscene::EndCutScene()
extern void EndCutscene_EndCutScene_mCB4E23A29CF43C5630AB869973FF622AEA153952 (void);
// 0x000000AC System.Void EndCutscene::.ctor()
extern void EndCutscene__ctor_m1BE1D1A9B95F1CDC9BE34E40549F26F354ABD318 (void);
// 0x000000AD System.Collections.IEnumerator EndCutscene::<BeginCutScene>g__WaitTilTheEndU7C0_0()
extern void EndCutscene_U3CBeginCutSceneU3Eg__WaitTilTheEndU7C0_0_m62847328BAA3D4C94584AF25F10F2807A1A458A3 (void);
// 0x000000AE System.Void BasicColliderBegin::OnTriggerEnter2D(UnityEngine.Collider2D)
extern void BasicColliderBegin_OnTriggerEnter2D_m3E04F4064800A7D046940FFDD806E43DF63D66BF (void);
// 0x000000AF System.Void BasicColliderBegin::.ctor()
extern void BasicColliderBegin__ctor_m46E06EE964E9DF53545F0FE18705D6D8952496F8 (void);
// 0x000000B0 System.Void DialogueLoader::Start()
extern void DialogueLoader_Start_mCC9AD077F73FC6AF99A74086ABC9E89177384462 (void);
// 0x000000B1 System.Void DialogueLoader::Update()
extern void DialogueLoader_Update_m40A8A98231F951AF1B917A96CD1BD2713E4F92CB (void);
// 0x000000B2 System.Void DialogueLoader::.ctor()
extern void DialogueLoader__ctor_m02642214B880AF2B01D61320A83EEF7DE88CD3D4 (void);
// 0x000000B3 System.Boolean KInput::get_lockControls()
extern void KInput_get_lockControls_m56363EE2260D8EEB7BCADE3124F6EF587620A9CF (void);
// 0x000000B4 System.Void KInput::set_lockControls(System.Boolean)
extern void KInput_set_lockControls_m47F1E7D3F2E4C5559FC57D5D3AB398CD41E09162 (void);
// 0x000000B5 System.Boolean KInput::get_lockMovement()
extern void KInput_get_lockMovement_mD3944C1AFBEBC90ED569382DA1C4EB2DA97EA900 (void);
// 0x000000B6 System.Void KInput::set_lockMovement(System.Boolean)
extern void KInput_set_lockMovement_mC831D884421400C0682D20B9C2574E7D37B3A3F7 (void);
// 0x000000B7 System.Boolean KInput::get_lockDialogueControls()
extern void KInput_get_lockDialogueControls_m4A368FD6120AA9259FDA2E31EDFFC44F845D3098 (void);
// 0x000000B8 System.Void KInput::set_lockDialogueControls(System.Boolean)
extern void KInput_set_lockDialogueControls_m8C801CF6C7247A0B50E0A2BD4E141AA9A81AFA9D (void);
// 0x000000B9 System.Boolean KInput::DialogueInput()
extern void KInput_DialogueInput_m823C7A75B838BE602E462174D904FEF7DF642284 (void);
// 0x000000BA System.Single KInput::Horizontal()
extern void KInput_Horizontal_mF14838BE8DACC225FE2EB198B51E8A975AAF7EDE (void);
// 0x000000BB System.Int32 KInput::FlatHorizontal()
extern void KInput_FlatHorizontal_m7F90E1C479465E6DFF8DBAB1842CADCCA3D66A07 (void);
// 0x000000BC System.Single KInput::Vertical()
extern void KInput_Vertical_m5A728A02C318C388BF1852846C5299E373223899 (void);
// 0x000000BD System.Int32 KInput::FlatVertical()
extern void KInput_FlatVertical_mEE90C4125A1CF491D28FCC03C05E69E359ABD756 (void);
// 0x000000BE System.Boolean KInput::JumpInputDown()
extern void KInput_JumpInputDown_m614BFC6F510AD364A97F2B0897820BD5EEED7F95 (void);
// 0x000000BF System.Boolean KInput::JumpInput()
extern void KInput_JumpInput_mE29A0CFF30962C399247D2FBF584FFA65A0AE385 (void);
// 0x000000C0 System.Boolean KInput::WieldInput()
extern void KInput_WieldInput_mFCEBDE4E727938B3A9273DB487AE8E32905FFEE7 (void);
// 0x000000C1 System.Boolean KInput::WieldInputDown()
extern void KInput_WieldInputDown_m810D242FA840503620FA4787AE7614634E6A0E79 (void);
// 0x000000C2 System.Boolean KInput::BurstInput()
extern void KInput_BurstInput_m3496F87BA4449350A440DFE99F201E3DD87B5DA5 (void);
// 0x000000C3 System.Boolean KInput::PauseInput()
extern void KInput_PauseInput_mD7D41697F56F021C77E697600BF64DEBA416791A (void);
// 0x000000C4 System.Int32 KInput::VerticalMenu()
extern void KInput_VerticalMenu_mA3742A0B16FA3A7D19674084D928A6A15CE42CD1 (void);
// 0x000000C5 System.Int32 KInput::HorizontalMenu()
extern void KInput_HorizontalMenu_mE9194864FC9BA17D90E988678089DABD965B11D0 (void);
// 0x000000C6 System.Boolean KInput::MenuSelect()
extern void KInput_MenuSelect_mAC303F98AC161B96548ECF6A5CFEF9D0BD2C1A9B (void);
// 0x000000C7 System.Void KInput::.cctor()
extern void KInput__cctor_m039B1AA347FB071B042E2747F91B552F19E08EEB (void);
// 0x000000C8 System.Void SoundEngine::Start()
extern void SoundEngine_Start_mAA676425126C5951949258FD88B3654965C0E470 (void);
// 0x000000C9 System.Void SoundEngine::Update()
extern void SoundEngine_Update_m589B45D10103D7B78F11800E551ED6C1795CD744 (void);
// 0x000000CA System.Void SoundEngine::.ctor()
extern void SoundEngine__ctor_m2BD5204C94BD004FFCAF17F073377B5BF907DF15 (void);
// 0x000000CB System.Void SoundEngine::.cctor()
extern void SoundEngine__cctor_m22359431FDE6457552A6FFAA1D98CC22749F7695 (void);
// 0x000000CC System.Void CloudTree::Start()
extern void CloudTree_Start_mD5F636CA2C8D21B7D61822C72123D9AB316C2FEB (void);
// 0x000000CD System.Void CloudTree::Update()
extern void CloudTree_Update_m06539B428DFCC9430FAE9A939546FE3F71A887DE (void);
// 0x000000CE System.Void CloudTree::AddVelocity()
extern void CloudTree_AddVelocity_m477263ED04DD1F8C70140924DF5500407A88CE88 (void);
// 0x000000CF System.Collections.IEnumerator CloudTree::WaitABit()
extern void CloudTree_WaitABit_mB34404F80270A843B563869DD2377F5FE093DC41 (void);
// 0x000000D0 System.Void CloudTree::Effect()
extern void CloudTree_Effect_m29ED7C9375D72085D7A558175C66EB15C1B927DE (void);
// 0x000000D1 System.Void CloudTree::OnDrawGizmosSelected()
extern void CloudTree_OnDrawGizmosSelected_m99D8EBD5CD5E48F8C2FC80B9875D3C7DADD07BD5 (void);
// 0x000000D2 System.Void CloudTree::.ctor()
extern void CloudTree__ctor_m302E17CEBBF23EFAFCE02F3DCE5AEDF42A44434B (void);
// 0x000000D3 System.Void LeafPiece::Awake()
extern void LeafPiece_Awake_m8ADB1B193664705EA022B2478DDD3FB4FE0396C3 (void);
// 0x000000D4 System.Void LeafPiece::CheckRoom()
extern void LeafPiece_CheckRoom_mB38E4C67CBD52D407F98FDD7E0C360051C6DDBFE (void);
// 0x000000D5 System.Void LeafPiece::Activate()
extern void LeafPiece_Activate_m2CA8E03DB437180C7ECFE2B88FC3C10CE0D0CBC8 (void);
// 0x000000D6 System.Void LeafPiece::KUpdate()
extern void LeafPiece_KUpdate_m6A1A68FC5E48318CB90B61675081F47E5E536F70 (void);
// 0x000000D7 System.Void LeafPiece::KLateUpdateImageEffect()
extern void LeafPiece_KLateUpdateImageEffect_mB9FE052922B3BF404F105B003500D0F9C481F0CA (void);
// 0x000000D8 System.Void LeafPiece::LoadData()
extern void LeafPiece_LoadData_mADC0B38DE793C69D8ED48BDF0D2DD5C89FC8AF0F (void);
// 0x000000D9 System.Void LeafPiece::.ctor()
extern void LeafPiece__ctor_mFC6D9674DC70E138542D0BABB79965B49A43E762 (void);
// 0x000000DA System.Void Scrunge::Start()
extern void Scrunge_Start_m36CFB6E56A22AB24DEA6D7406F8680085DF09205 (void);
// 0x000000DB System.Void Scrunge::KUpdate()
extern void Scrunge_KUpdate_m4EA2D40A76023C7742140B71C080EE096096815F (void);
// 0x000000DC System.Void Scrunge::BounceUpdate()
extern void Scrunge_BounceUpdate_m4C60E8B72532A097320BC1E4EFEDFDE1A19532CA (void);
// 0x000000DD System.Void Scrunge::AddVelocity()
extern void Scrunge_AddVelocity_m90EB05816B159A4974B0E1ABD349692FAB1871B0 (void);
// 0x000000DE System.Void Scrunge::LoadData()
extern void Scrunge_LoadData_m974E1DA18BAED784BD6A98B0D7B4A7957CC4EAC6 (void);
// 0x000000DF System.Void Scrunge::SaveData()
extern void Scrunge_SaveData_mB2D041CADC5CDCF5ED9FE703F68108FAA621AC39 (void);
// 0x000000E0 System.Void Scrunge::Activate()
extern void Scrunge_Activate_m69682DF0ECCAB5986D3FF49AD3BB68F7423CA344 (void);
// 0x000000E1 System.Void Scrunge::StartGoin()
extern void Scrunge_StartGoin_mF28F59B7F178BB8E07E6866962FF2A396521E04E (void);
// 0x000000E2 System.Void Scrunge::StopGoin()
extern void Scrunge_StopGoin_mCD0B705770B5D6AEC19275FF651FFB9CAFA53D19 (void);
// 0x000000E3 System.Void Scrunge::HandleMovement()
extern void Scrunge_HandleMovement_m412BB780432A7C04ED2CFB8D687BA74997873E4B (void);
// 0x000000E4 System.Void Scrunge::UseVelocity()
extern void Scrunge_UseVelocity_m9029A831A7B417F61A2CF9D482CA0E4636CDEA93 (void);
// 0x000000E5 System.Void Scrunge::CheckGrounded()
extern void Scrunge_CheckGrounded_m6521A5DD976C7EF26F15EC2E637AD06EEE783C7E (void);
// 0x000000E6 System.Void Scrunge::Gravity()
extern void Scrunge_Gravity_m0886A67463E6B809FB8069C448FDC3990E2FF53E (void);
// 0x000000E7 System.Void Scrunge::HandleWallCollisions()
extern void Scrunge_HandleWallCollisions_mA34327F3B5E452043492272E3F9D4CF7D3844B84 (void);
// 0x000000E8 System.Boolean Scrunge::CheckCollisionSide(UnityEngine.Vector2,System.Int32,System.Single)
extern void Scrunge_CheckCollisionSide_m2C1F14FCAB99CD206E5029E56F584EA2C0F289A5 (void);
// 0x000000E9 System.Void Scrunge::OnDrawGizmos()
extern void Scrunge_OnDrawGizmos_mC3AFBFBD7F054F76ED28AA2AFADD5A8B31E0A7F5 (void);
// 0x000000EA System.Void Scrunge::.ctor()
extern void Scrunge__ctor_m2810C0C27E0C2C1022A98D021A3C26230597BDF7 (void);
// 0x000000EB System.Void PartBase::Start()
extern void PartBase_Start_m2B577505F42FF308995D2BE32F6ED24C0973C71A (void);
// 0x000000EC System.Void PartBase::TryActivate()
extern void PartBase_TryActivate_m132A6A8435DB03EE665428A50C081FED1D711FC6 (void);
// 0x000000ED System.Void PartBase::Activate()
// 0x000000EE System.Void PartBase::.ctor()
extern void PartBase__ctor_mE84EAAD997E39F071B68D3FE87DFB9ECA836F600 (void);
// 0x000000EF System.Void PlatformCollider::Start()
extern void PlatformCollider_Start_mF7977F6F2871EBBC1DD0A6C887BA46CB65FAA6E8 (void);
// 0x000000F0 System.Void PlatformCollider::Update()
extern void PlatformCollider_Update_mC946794E09C6C1EA2286B8005CED83F4AEFAA008 (void);
// 0x000000F1 System.Void PlatformCollider::.ctor()
extern void PlatformCollider__ctor_m11105413D5B56D6A485E67F2B3E4BCF43637C3B7 (void);
// 0x000000F2 System.Void Conjunctor::Start()
extern void Conjunctor_Start_m23B713A1A9FAE3BE3E7081D65EBCFCE9B4273E26 (void);
// 0x000000F3 System.Void Conjunctor::Awake()
extern void Conjunctor_Awake_m4DFC723B5B089486C95BB6A7F55E667A518BEB2C (void);
// 0x000000F4 System.Collections.IEnumerator Conjunctor::WaitForSpriteRenderer()
extern void Conjunctor_WaitForSpriteRenderer_m7A157D81E1118959E250EC0BB60BA12A61F76E51 (void);
// 0x000000F5 System.Void Conjunctor::KUpdate()
extern void Conjunctor_KUpdate_m16CB34F37684090AD4849E75FB7DEC7FB231AE07 (void);
// 0x000000F6 System.Void Conjunctor::.ctor()
extern void Conjunctor__ctor_m23DD5027E85EE2C263EE8EBD2AFC76E8B2EFE7D2 (void);
// 0x000000F7 System.Void EnergyBurstVisual::Start()
extern void EnergyBurstVisual_Start_mD40BE942A40EAFE72CFD97FD8519E7560B0DE2B2 (void);
// 0x000000F8 System.Void EnergyBurstVisual::Update()
extern void EnergyBurstVisual_Update_m1DE2C8F7132CA35E2C59119525DA716FEFFB5BB4 (void);
// 0x000000F9 System.Void EnergyBurstVisual::.ctor()
extern void EnergyBurstVisual__ctor_mA3F0DDCB3878AAD4E6B161961312D919EF272C45 (void);
// 0x000000FA System.Void HandleAnimation::Start()
extern void HandleAnimation_Start_m4508FCFE6E0FC079D22AB09A0F49DBC28A2929D8 (void);
// 0x000000FB System.Void HandleAnimation::Update()
extern void HandleAnimation_Update_m08353A5E52E52FCA7A2D20367258AC22C147117B (void);
// 0x000000FC System.Void HandleAnimation::LateUpdate()
extern void HandleAnimation_LateUpdate_mCE2952922513D6149125A63887D10096161A58CD (void);
// 0x000000FD System.Void HandleAnimation::.ctor()
extern void HandleAnimation__ctor_m1AC6A137D0811A09D29E94631D269C4EE7EC1364 (void);
// 0x000000FE System.Void DestroyParticleOnEnd::Start()
extern void DestroyParticleOnEnd_Start_mB72FD71BF0B79F34DCCE7289CDA57DA5C8AA85B0 (void);
// 0x000000FF System.Void DestroyParticleOnEnd::Update()
extern void DestroyParticleOnEnd_Update_m2A72A53B49DA2F2710C04D217698D8F886D37F25 (void);
// 0x00000100 System.Void DestroyParticleOnEnd::.ctor()
extern void DestroyParticleOnEnd__ctor_m745B4493C8E6AD1753BC3AA40B9F6B5833B5D553 (void);
// 0x00000101 System.Void ParticleHandler::Start()
extern void ParticleHandler_Start_m74D89BFB259137323493C15703175832BCC09027 (void);
// 0x00000102 System.Void ParticleHandler::Update()
extern void ParticleHandler_Update_m3E3452A46F8135792E57B01682FE33C6FA21CF54 (void);
// 0x00000103 System.Void ParticleHandler::SpawnParticleSystem()
extern void ParticleHandler_SpawnParticleSystem_m71E8ED2BE7FA7778DD67EDD77C40A2430610F67A (void);
// 0x00000104 System.Void ParticleHandler::HandleWallSliding()
extern void ParticleHandler_HandleWallSliding_m3ADABE0FE0864EA2DB704BD7264AC4B004A8A244 (void);
// 0x00000105 System.Void ParticleHandler::.ctor()
extern void ParticleHandler__ctor_mDA0C1D3873A4184C6FFE06C3B00747AFDFCA047F (void);
// 0x00000106 System.Void PlayerControl::add_hitGround(System.Action)
extern void PlayerControl_add_hitGround_mB87F9CE81272CB4AC4BD6ADAD11CD23E3DF6F0A3 (void);
// 0x00000107 System.Void PlayerControl::remove_hitGround(System.Action)
extern void PlayerControl_remove_hitGround_m5FEED0DB47A7E7653018D3A3153CD5C9F5295FD7 (void);
// 0x00000108 System.Void PlayerControl::add_jumped(System.Action)
extern void PlayerControl_add_jumped_mC6B4CE145E13B43F8D4C4E9C816ADDEAECAA92B5 (void);
// 0x00000109 System.Void PlayerControl::remove_jumped(System.Action)
extern void PlayerControl_remove_jumped_m4EE047959F383AE54845AF791A955DF328F56293 (void);
// 0x0000010A System.Void PlayerControl::Start()
extern void PlayerControl_Start_m9E68769B521728F3CA952D11BA9AE068461048BF (void);
// 0x0000010B System.Void PlayerControl::Update()
extern void PlayerControl_Update_mB6BCD0B5C42037B3D8791A472BF6290B1937A58D (void);
// 0x0000010C System.Void PlayerControl::PlayerUpdate()
extern void PlayerControl_PlayerUpdate_m95E6B35AAC3FA8CC136807714548191E2BC0395F (void);
// 0x0000010D System.Void PlayerControl::HandleMovement()
extern void PlayerControl_HandleMovement_m087C2E4F647DED88AA73E76589CB3FE503620B86 (void);
// 0x0000010E System.Void PlayerControl::ApplyAcceleration(System.Single)
extern void PlayerControl_ApplyAcceleration_m8D538A2F7B545F8A7E3ABE73661A500B2BF8EB4C (void);
// 0x0000010F System.Void PlayerControl::ApplyDeceleration(System.Single)
extern void PlayerControl_ApplyDeceleration_m0AFD62873F2E3D0BA2815F22D04DDC78A73AB976 (void);
// 0x00000110 System.Void PlayerControl::HandleWallCollisions()
extern void PlayerControl_HandleWallCollisions_m6E32ED141B93FD9208164C961B90AFB346CC8DD6 (void);
// 0x00000111 System.Boolean PlayerControl::CheckCollisionSide(UnityEngine.Vector2,System.Int32,System.Single)
extern void PlayerControl_CheckCollisionSide_m962CAFB5233C69A1584F03D4DF19F21926855001 (void);
// 0x00000112 System.Void PlayerControl::CheckGrounded()
extern void PlayerControl_CheckGrounded_m19288AF245DFF62BA44D0CE23C29967F2D35AE30 (void);
// 0x00000113 System.String PlayerControl::GetGroundedTag()
extern void PlayerControl_GetGroundedTag_mCCF8A5B59E61D35D51136345BF931D7C075E527B (void);
// 0x00000114 System.Void PlayerControl::Gravity()
extern void PlayerControl_Gravity_m46058E2ED16510B2C4501A879E72EE5EBB1EFA78 (void);
// 0x00000115 System.Void PlayerControl::HandleJump()
extern void PlayerControl_HandleJump_m172F3717C4E3A16DB03F4B338D76195886D50D90 (void);
// 0x00000116 System.Void PlayerControl::Jump()
extern void PlayerControl_Jump_m9A657B9CC98D53BD12AC60BCFA9C59EF5F852EE4 (void);
// 0x00000117 System.Void PlayerControl::WallJump()
extern void PlayerControl_WallJump_m80C0249B83305723EB949EDC9D6E46ECCC1DA971 (void);
// 0x00000118 System.Boolean PlayerControl::HandleBonk()
extern void PlayerControl_HandleBonk_m42B24D9659FE83849B7E85F238979D7B6D692348 (void);
// 0x00000119 System.Void PlayerControl::OnDrawGizmos()
extern void PlayerControl_OnDrawGizmos_mD4CCFC29DD8EE6BEA6F8C867A08916F264FE7932 (void);
// 0x0000011A System.Void PlayerControl::.ctor()
extern void PlayerControl__ctor_mFB09FAB1E5EE3D8037BC0D0DF9294BB501A5C869 (void);
// 0x0000011B System.Void ReturnByDeath::Start()
extern void ReturnByDeath_Start_mD6518959257C98B68F052FFAA021AB0E05AE69CC (void);
// 0x0000011C System.Void ReturnByDeath::OnApplicationQuit()
extern void ReturnByDeath_OnApplicationQuit_m52CA4D692F53B0C7FAD9E2437D627D56DCA29267 (void);
// 0x0000011D System.Void ReturnByDeath::OnTriggerEnter2D(UnityEngine.Collider2D)
extern void ReturnByDeath_OnTriggerEnter2D_mF5F7AB2AA79660D30E426222E9807100C7D22DF3 (void);
// 0x0000011E System.Void ReturnByDeath::Death()
extern void ReturnByDeath_Death_mE09DFE330B861C8947CE85E9CC79C831E305A85F (void);
// 0x0000011F System.Collections.IEnumerator ReturnByDeath::WaitForDeathToEnd()
extern void ReturnByDeath_WaitForDeathToEnd_m2D588917796C1033B728EA18D7497CF530C24D64 (void);
// 0x00000120 System.Void ReturnByDeath::IFICOULDCHANGEMYTEARSINTOSTRENGTHANDPOWERMAYBEICOULDREACHTHEFUTUREISEEINMYMIND_BRING_IT_TO_LIFEE()
extern void ReturnByDeath_IFICOULDCHANGEMYTEARSINTOSTRENGTHANDPOWERMAYBEICOULDREACHTHEFUTUREISEEINMYMIND_BRING_IT_TO_LIFEE_mFED9DD2699FDF4D7A419C89BE3B484EC977ED52D (void);
// 0x00000121 System.Void ReturnByDeath::ReloadPlayer()
extern void ReturnByDeath_ReloadPlayer_mB08799AB787CB0447421090DF76E9317F6EBF459 (void);
// 0x00000122 System.Void ReturnByDeath::.ctor()
extern void ReturnByDeath__ctor_m7DD839BB219D264A30E420A8636783F92B795A4B (void);
// 0x00000123 System.Void ReturnByDeath::.cctor()
extern void ReturnByDeath__cctor_m29C1AE02A454E43AACB4A5CD3BE60E8DEE2836B4 (void);
// 0x00000124 System.Void PlayerSound::Start()
extern void PlayerSound_Start_mC3A6B7493D417266D29C0703AA2A0813145D8380 (void);
// 0x00000125 System.Void PlayerSound::Update()
extern void PlayerSound_Update_mAB715EB4017653264E213B3AB8F1B13A371E465D (void);
// 0x00000126 System.Void PlayerSound::JumpNoise()
extern void PlayerSound_JumpNoise_m2BAAEAEDA36C4D07F5ADC0AA606F06D4F884FFEB (void);
// 0x00000127 System.Void PlayerSound::StepNoise()
extern void PlayerSound_StepNoise_m0C74831594F98329DA23826B02F259E843D2C3CE (void);
// 0x00000128 UnityEngine.AudioClip PlayerSound::GetCurrentAudioClip()
extern void PlayerSound_GetCurrentAudioClip_mC2DEFF22C83839CEEB203E81DBBEEA90F7B62D48 (void);
// 0x00000129 System.Void PlayerSound::.ctor()
extern void PlayerSound__ctor_m1F6B8AEDBD15A16C01E9E9BD119739C6467665BE (void);
// 0x0000012A System.Void Wielder::add_wieldActivation(System.Action)
extern void Wielder_add_wieldActivation_mB8091E276A83C6429D0BDE841E049E2A9EA054FB (void);
// 0x0000012B System.Void Wielder::remove_wieldActivation(System.Action)
extern void Wielder_remove_wieldActivation_m2BE9DC75622459679EF08FE17C7EA64F8FBF2A46 (void);
// 0x0000012C System.Void Wielder::Start()
extern void Wielder_Start_m187C6AB7DA88AEDD3F07B599AEECE056B7DCB32C (void);
// 0x0000012D System.Void Wielder::ClearEvent()
extern void Wielder_ClearEvent_m853576415D47FE5ACC9B80A6D44B6DE03A7939BF (void);
// 0x0000012E System.Void Wielder::WieldUpdate()
extern void Wielder_WieldUpdate_mE32DE60EB4E9433913C71EE846A164B737AFA369 (void);
// 0x0000012F System.Void Wielder::LateUpdate()
extern void Wielder_LateUpdate_m0DEA4B56C8F54A18FE5241627BDAD5B5B2B5AF9B (void);
// 0x00000130 System.Void Wielder::EnergyBurst()
extern void Wielder_EnergyBurst_m7F00DE389A3539D5A3D569316B65AC7EC4F2AF46 (void);
// 0x00000131 System.Void Wielder::Blink()
extern void Wielder_Blink_mAD425DD75F24916FA097A28E58C114CA71754E8A (void);
// 0x00000132 System.Void Wielder::VelocityShift()
extern void Wielder_VelocityShift_m545F881D1FF689976D92CF57B5FBF2BF04442A85 (void);
// 0x00000133 System.Collections.IEnumerator Wielder::VelocityControl()
extern void Wielder_VelocityControl_m00D2DC47C46C610658EB642B97344CCF5E65FC4B (void);
// 0x00000134 System.Void Wielder::.ctor()
extern void Wielder__ctor_mBB3D81A42693654DD537906E90D6A3971EF733ED (void);
// 0x00000135 System.Void Chapter0CutScene::BeginCutScene()
extern void Chapter0CutScene_BeginCutScene_mCF0A051D2CFB9F677845FFB5CCA62E78F689DC9D (void);
// 0x00000136 System.Void Chapter0CutScene::EndCutScene()
extern void Chapter0CutScene_EndCutScene_m8B641EFE6FF6EB46330724FF31C2913A7A643387 (void);
// 0x00000137 System.Collections.IEnumerator Chapter0CutScene::MovePlayer()
extern void Chapter0CutScene_MovePlayer_mB20CE757487E0DF83AA41EAF88C57536F7B3FD6A (void);
// 0x00000138 System.Void Chapter0CutScene::.ctor()
extern void Chapter0CutScene__ctor_m2A75CD6B0A15B01A7A73092A004442EFE91A402D (void);
// 0x00000139 System.Void WakeUpDialogue::OnTriggerEnter2D(UnityEngine.Collider2D)
extern void WakeUpDialogue_OnTriggerEnter2D_mBE9882C63A8C938366C549C906EF48D1FD124B19 (void);
// 0x0000013A System.Void WakeUpDialogue::.ctor()
extern void WakeUpDialogue__ctor_m337A44C5B6AD5FF19139B284E025E933CE26A939 (void);
// 0x0000013B System.Void Chapter1Collider::Start()
extern void Chapter1Collider_Start_m5C310C6CB63DFB535DFD018328AED25C1F18796E (void);
// 0x0000013C System.Void Chapter1Collider::Update()
extern void Chapter1Collider_Update_mE7C97B997585E270E613C794CB621DE6E42A3FDB (void);
// 0x0000013D System.Void Chapter1Collider::.ctor()
extern void Chapter1Collider__ctor_m469BAB018A07D3C736BB4B595E6913D15547CEB7 (void);
// 0x0000013E System.Void CutSceneChapter1End::BeginCutScene()
extern void CutSceneChapter1End_BeginCutScene_m0DADC648233997AA4C9BCCCFC5DCB074CD15F4BB (void);
// 0x0000013F System.Void CutSceneChapter1End::EndCutScene()
extern void CutSceneChapter1End_EndCutScene_m5702B5757BC55CB9EB786529CDF51133493BFB35 (void);
// 0x00000140 System.Void CutSceneChapter1End::.ctor()
extern void CutSceneChapter1End__ctor_m27C379E0957CE35113DD12893C0D7638A15A521D (void);
// 0x00000141 System.Void GoNextChapter::OnTriggerEnter2D(UnityEngine.Collider2D)
extern void GoNextChapter_OnTriggerEnter2D_m9621735E48F2AA06DEA3AB607BEFE76825310F20 (void);
// 0x00000142 System.Void GoNextChapter::Thing()
extern void GoNextChapter_Thing_mAA9DA5380A844F53B4FC45DC7DF494984F0D3823 (void);
// 0x00000143 System.Void GoNextChapter::.ctor()
extern void GoNextChapter__ctor_m10A30A5F5CE2DDC66211B5274BB6A47EF356E9F6 (void);
// 0x00000144 System.Collections.IEnumerator GoNextChapter::<Thing>g__waitForFadeU7C2_0()
extern void GoNextChapter_U3CThingU3Eg__waitForFadeU7C2_0_mAB35DE4A29323D2586899ACC98FF29D792B60FA5 (void);
// 0x00000145 System.Void RunChapter1End::Start()
extern void RunChapter1End_Start_m4CEFAAEAB5D7615B2C9BA8A87E5A31D8B23D2A1C (void);
// 0x00000146 System.Void RunChapter1End::OnTriggerEnter2D(UnityEngine.Collider2D)
extern void RunChapter1End_OnTriggerEnter2D_m5C078563E6FBDE57208CCAA7395E1311E03D7D27 (void);
// 0x00000147 System.Void RunChapter1End::.ctor()
extern void RunChapter1End__ctor_m8CE1E759A7FA4E0823EB02D08FFF57DEE586C826 (void);
// 0x00000148 System.Boolean SiblingRuleTile::RuleMatch(System.Int32,UnityEngine.Tilemaps.TileBase)
extern void SiblingRuleTile_RuleMatch_mA548BA6DC40A64FBF82BA773FEDA5104F3E4C256 (void);
// 0x00000149 System.Void SiblingRuleTile::.ctor()
extern void SiblingRuleTile__ctor_m86B52B459F7636693438DF610B110641F71A41FB (void);
// 0x0000014A UnityEngine.Texture2D SpriteModifier::ConvertSpriteToNewTex2D(UnityEngine.Sprite)
extern void SpriteModifier_ConvertSpriteToNewTex2D_mD81D4845BB2F1332179885DA47B02EE372536CF1 (void);
// 0x0000014B UnityEngine.Sprite SpriteModifier::ConvertTexture2DToSprite(UnityEngine.Texture2D,UnityEngine.Vector2)
extern void SpriteModifier_ConvertTexture2DToSprite_mB358E63284C4928D1153A49348F44B17785FAF76 (void);
// 0x0000014C UnityEngine.Vector2 SpriteModifier::GetPivotInWorld(UnityEngine.Sprite)
extern void SpriteModifier_GetPivotInWorld_mD3DB7CE75C1B01DC26A9BD6693141D53ED031B0A (void);
// 0x0000014D UnityEngine.Sprite SpriteModifier::ReplaceColor(UnityEngine.Sprite,UnityEngine.Color,UnityEngine.Color)
extern void SpriteModifier_ReplaceColor_m19D6B06DDBF60AFE58A44735F1C8E0F0F9654FD4 (void);
// 0x0000014E UnityEngine.Sprite SpriteModifier::TintColor(UnityEngine.Sprite,UnityEngine.Color,System.Single)
extern void SpriteModifier_TintColor_m703301CC6274D798C69C4BC8A5525F5FBAE572D6 (void);
// 0x0000014F UnityEngine.Sprite SpriteModifier::Interp(UnityEngine.Sprite,UnityEngine.Color,UnityEngine.Color,System.Single,System.Boolean)
extern void SpriteModifier_Interp_mD826021B3B9258DC8E5113FA540242ACBB823441 (void);
// 0x00000150 UnityEngine.Sprite SpriteModifier::GrayScale(UnityEngine.Sprite,System.Single)
extern void SpriteModifier_GrayScale_m3C896045E5E2DEAAE8A7FFF64424C43B7F8CEC7E (void);
// 0x00000151 System.Void WinScreen::Start()
extern void WinScreen_Start_mDFE8D3BF639D488F892A129704B0E9C507197D06 (void);
// 0x00000152 System.Void WinScreen::UpdateRecord()
extern void WinScreen_UpdateRecord_m8067D786ED54883320FB81F6D30049FF6B9C0080 (void);
// 0x00000153 System.Void WinScreen::UpdateCollectables()
extern void WinScreen_UpdateCollectables_m96ABEABF2F51BD175C837B57E819B580DEDF593F (void);
// 0x00000154 System.Void WinScreen::Update()
extern void WinScreen_Update_m1C20AA53074CCC3BF1DD9CB95A2925F5F0B43A1E (void);
// 0x00000155 System.Void WinScreen::.ctor()
extern void WinScreen__ctor_m74A324860E652FFA4A26DD8E21810F4B79EC906F (void);
// 0x00000156 System.Void WinScreen::<UpdateRecord>g__DeclareNewRecordU7C6_0()
extern void WinScreen_U3CUpdateRecordU3Eg__DeclareNewRecordU7C6_0_mD252D6B98328199D13BD1F98EE4B25E48910062F (void);
// 0x00000157 System.Void KyleSystem.DialogueSystem.DialogueAnimator::Start()
extern void DialogueAnimator_Start_m8F172C6AACC682D5AF328C061C2931A79707803B (void);
// 0x00000158 System.Void KyleSystem.DialogueSystem.DialogueAnimator::PlaySelf()
extern void DialogueAnimator_PlaySelf_mC4EC45A1457FE44EF1CCDB37C067B5AE0241474E (void);
// 0x00000159 System.Void KyleSystem.DialogueSystem.DialogueAnimator::ForceEnd()
extern void DialogueAnimator_ForceEnd_m3671F6AA9928BC6D4F23D58283DC5AA911066E03 (void);
// 0x0000015A System.Void KyleSystem.DialogueSystem.DialogueAnimator::.ctor()
extern void DialogueAnimator__ctor_m5631C331A743E244AF2722291C895C375508A26B (void);
// 0x0000015B System.Void KyleSystem.DialogueSystem.DialogueBox::Start()
extern void DialogueBox_Start_m190C0010BD7C5C98C55B21E1E034083E06E18BDF (void);
// 0x0000015C System.Void KyleSystem.DialogueSystem.DialogueBox::OnDestroy()
extern void DialogueBox_OnDestroy_mE8D89300842D3FC144FC03C7646117ACD126F05E (void);
// 0x0000015D System.Void KyleSystem.DialogueSystem.DialogueBox::UpdateVisibility()
extern void DialogueBox_UpdateVisibility_m6CAFEEC5308671D4BAECF44FEE77B41EC99F0ED2 (void);
// 0x0000015E System.Void KyleSystem.DialogueSystem.DialogueBox::UpdatePosition()
extern void DialogueBox_UpdatePosition_m6A9BED8FB3D23EF75AF3B0EF6A73548F9755648A (void);
// 0x0000015F System.Void KyleSystem.DialogueSystem.DialogueBox::SetVisible(System.Boolean)
extern void DialogueBox_SetVisible_m04BDCD11ACCF598BCD9D93051E6BC1C0A422C979 (void);
// 0x00000160 System.Void KyleSystem.DialogueSystem.DialogueBox::UpdateName()
extern void DialogueBox_UpdateName_m224BEDDF6C8AC581D7DEFD4F6A4A352ECB5EB10D (void);
// 0x00000161 System.Void KyleSystem.DialogueSystem.DialogueBox::UpdateFace()
extern void DialogueBox_UpdateFace_m998DDF2D0AE24FE1752FAB7AA747018B4E76B18B (void);
// 0x00000162 System.Void KyleSystem.DialogueSystem.DialogueBox::.ctor()
extern void DialogueBox__ctor_m47113684FCF3186E4E5CD0F442349DE0B31ADE2D (void);
// 0x00000163 System.Void KyleSystem.DialogueSystem.DialogueBox::.cctor()
extern void DialogueBox__cctor_m1A67F9D91018A8659E24B2441766D19C491538C7 (void);
// 0x00000164 System.Void KyleSystem.DialogueSystem.DialogueListener::Start()
extern void DialogueListener_Start_mA3E945EE3E457783AC5FE22061D073F41840529A (void);
// 0x00000165 System.Void KyleSystem.DialogueSystem.DialogueListener::OnDestroy()
extern void DialogueListener_OnDestroy_m12DFF0AB80F30B8AF0498D1503FF80DAEDC9C9AA (void);
// 0x00000166 System.Void KyleSystem.DialogueSystem.DialogueListener::End()
extern void DialogueListener_End_mEC950A0A3D67366D3569D320B4272EF45074B8CA (void);
// 0x00000167 System.Collections.IEnumerator KyleSystem.DialogueSystem.DialogueListener::DialogueTimer()
extern void DialogueListener_DialogueTimer_m44B953F980F20DDE000708DB1528D86236706AD8 (void);
// 0x00000168 System.Void KyleSystem.DialogueSystem.DialogueListener::Activate(System.String)
extern void DialogueListener_Activate_m6DA479C7C6F09971ECBCA7ACCD865EA63969A22C (void);
// 0x00000169 System.Void KyleSystem.DialogueSystem.DialogueListener::Activate(System.Int32)
extern void DialogueListener_Activate_m2CA424B0E109AC2FF2CBDF7E1EEE9E37F9E120C3 (void);
// 0x0000016A System.Void KyleSystem.DialogueSystem.DialogueListener::SetAnimators(System.Boolean)
extern void DialogueListener_SetAnimators_m74E39D35577DF4B2AF00F6985DD7FF79FB89FB52 (void);
// 0x0000016B System.Void KyleSystem.DialogueSystem.DialogueListener::.ctor()
extern void DialogueListener__ctor_m2831654C736BAC57C0BA9BB3DFCB3B230D166239 (void);
// 0x0000016C System.Void KyleSystem.DialogueSystem.DialogueListener::.cctor()
extern void DialogueListener__cctor_m1BB7B4AF015008757DBA89BE93B82DA2392FF72D (void);
// 0x0000016D System.Void KyleSystem.DialogueSystem.DialogueSounds::Awake()
extern void DialogueSounds_Awake_mB596BC3D70DB758A0AFE3B989A4E7D74B8D7AD4D (void);
// 0x0000016E System.Void KyleSystem.DialogueSystem.DialogueSounds::PlaySound()
extern void DialogueSounds_PlaySound_mAA09A52B5F291B53E0B902563E7142169DD5CBDA (void);
// 0x0000016F System.Void KyleSystem.DialogueSystem.DialogueSounds::.ctor()
extern void DialogueSounds__ctor_mEE7DDF36445038802FFDDAD1316720C80186363F (void);
// 0x00000170 System.Void KyleSystem.DialogueSystem.DialogueText::Start()
extern void DialogueText_Start_m5C5BB91B52EDE9A42A3A6CC36D9A0417712E357B (void);
// 0x00000171 System.Void KyleSystem.DialogueSystem.DialogueText::UpdateSelf()
extern void DialogueText_UpdateSelf_m51D9F8C8A988852AE82CCC04F15F935953F218C8 (void);
// 0x00000172 System.Void KyleSystem.DialogueSystem.DialogueText::OnDisable()
extern void DialogueText_OnDisable_m1AA74743FC36B13041EA49AF726BA345AD8EAC36 (void);
// 0x00000173 System.Void KyleSystem.DialogueSystem.DialogueText::.ctor()
extern void DialogueText__ctor_m28F202BDBC2FB8BE413C3C1C66DF7C6C11C7F8F2 (void);
// 0x00000174 KyleSystem.DialogueSystem.DialogueScene KyleSystem.DialogueSystem.DialogueSystem::get_cur()
extern void DialogueSystem_get_cur_m1FCF94C0E12775245145A8889B0D602CC2EA7B67 (void);
// 0x00000175 KyleSystem.DialogueSystem.DialoguePackage KyleSystem.DialogueSystem.DialogueSystem::get_pack()
extern void DialogueSystem_get_pack_m2D4F02FACD3DA250DFD1A651EEE7B5760A5A9BF9 (void);
// 0x00000176 System.Boolean KyleSystem.DialogueSystem.DialogueSystem::get_isRunning()
extern void DialogueSystem_get_isRunning_mCA448E584DBB4353EB16AAB9D0FAF27F6A0DC8E5 (void);
// 0x00000177 System.Void KyleSystem.DialogueSystem.DialogueSystem::add_DialogueCall(System.Action)
extern void DialogueSystem_add_DialogueCall_m37B1A799ED23EEC1E07BADEE81EE8737AF9E229D (void);
// 0x00000178 System.Void KyleSystem.DialogueSystem.DialogueSystem::remove_DialogueCall(System.Action)
extern void DialogueSystem_remove_DialogueCall_m8A6BC9342196795994F97B6AE77AB3B5A8EBF888 (void);
// 0x00000179 System.Void KyleSystem.DialogueSystem.DialogueSystem::add_SoundCall(System.Action)
extern void DialogueSystem_add_SoundCall_m44A8406BCC313BAE3358C7E75C3177CB1089DF56 (void);
// 0x0000017A System.Void KyleSystem.DialogueSystem.DialogueSystem::remove_SoundCall(System.Action)
extern void DialogueSystem_remove_SoundCall_mB0863FF3F8F694AC5FB999B0157C327FAF8D7A0A (void);
// 0x0000017B System.Void KyleSystem.DialogueSystem.DialogueSystem::add_AnimatorCall(System.Action)
extern void DialogueSystem_add_AnimatorCall_m996BFC400FEE54D5D9DC3936A22CA2CD4A71EFCD (void);
// 0x0000017C System.Void KyleSystem.DialogueSystem.DialogueSystem::remove_AnimatorCall(System.Action)
extern void DialogueSystem_remove_AnimatorCall_m5B19AC05886C15273171ED10677F2F09663B302F (void);
// 0x0000017D System.Void KyleSystem.DialogueSystem.DialogueSystem::add_AnimatorStopCall(System.Action)
extern void DialogueSystem_add_AnimatorStopCall_mC8B2D60C2B00B0134050800472A308BDDF0D5AA8 (void);
// 0x0000017E System.Void KyleSystem.DialogueSystem.DialogueSystem::remove_AnimatorStopCall(System.Action)
extern void DialogueSystem_remove_AnimatorStopCall_mE50C1D235DF1976D48534F6D0F36BAC454AAA596 (void);
// 0x0000017F System.Void KyleSystem.DialogueSystem.DialogueSystem::add_BeganPackage(System.Action)
extern void DialogueSystem_add_BeganPackage_m622934E35755F42DBB4C478162B7576C7212C72B (void);
// 0x00000180 System.Void KyleSystem.DialogueSystem.DialogueSystem::remove_BeganPackage(System.Action)
extern void DialogueSystem_remove_BeganPackage_m6D9CCD3B19EF78C7CDC41E6E8496C1F906002E2F (void);
// 0x00000181 System.Void KyleSystem.DialogueSystem.DialogueSystem::add_EndedPackage(System.Action)
extern void DialogueSystem_add_EndedPackage_mCD084592A6B93DC1DB852BCAD5961DD52FB4F491 (void);
// 0x00000182 System.Void KyleSystem.DialogueSystem.DialogueSystem::remove_EndedPackage(System.Action)
extern void DialogueSystem_remove_EndedPackage_m12765F60697035B5D421587DE5F7671F1A077A9F (void);
// 0x00000183 System.Void KyleSystem.DialogueSystem.DialogueSystem::BeginDialogue(System.String)
extern void DialogueSystem_BeginDialogue_m321A820A1BB466BA900CEC9B6A0BE6CE67AC564B (void);
// 0x00000184 System.Void KyleSystem.DialogueSystem.DialogueSystem::BeginDialogue(System.Int32)
extern void DialogueSystem_BeginDialogue_mF30024C22379F201960D3E0678048C9FEB30C4AA (void);
// 0x00000185 System.Void KyleSystem.DialogueSystem.DialogueSystem::SelectScene(System.String)
extern void DialogueSystem_SelectScene_m995E6D6E31A45627E41E061A6A8FFA809E02DCB8 (void);
// 0x00000186 System.Void KyleSystem.DialogueSystem.DialogueSystem::SelectScene(System.Int32)
extern void DialogueSystem_SelectScene_m3334404F320CD1CC783B39D4B27FC1CD57265754 (void);
// 0x00000187 System.Void KyleSystem.DialogueSystem.DialogueSystem::AdvanceDialogue()
extern void DialogueSystem_AdvanceDialogue_m3EAFCE87353892AC3199F9B4199F39D95884DF2C (void);
// 0x00000188 System.Void KyleSystem.DialogueSystem.DialogueSystem::ForceEndDialogue()
extern void DialogueSystem_ForceEndDialogue_mF56B7DD1E46CDC36E38D7CB93C7E42D1B941B13B (void);
// 0x00000189 System.Void KyleSystem.DialogueSystem.DialogueSystem::Sound()
extern void DialogueSystem_Sound_m0B2C36CA4A59CBF7296DA03FA2A0EAC8327ED7F7 (void);
// 0x0000018A System.Void KyleSystem.DialogueSystem.DialogueSystem::AnimateCurrent()
extern void DialogueSystem_AnimateCurrent_m81D5DDE7E7F1A1DBBCB3435E86D793EFC5156D12 (void);
// 0x0000018B System.Void KyleSystem.DialogueSystem.DialogueSystem::EndAnimations()
extern void DialogueSystem_EndAnimations_mC5C92D27E6C499F2FBD021606DE8F28CCC3E975A (void);
// 0x0000018C System.Void KyleSystem.DialogueSystem.DialogueSystem::AdvancePackage()
extern void DialogueSystem_AdvancePackage_m0129F112AF1978E3076EBD8BCC3857AA0C4C58F0 (void);
// 0x0000018D System.Void KyleSystem.DialogueSystem.DialogueSystem::EndCurrent()
extern void DialogueSystem_EndCurrent_m840482D6DAE022060B925194B1DF500DCE86603E (void);
// 0x0000018E System.Void KyleSystem.DialogueSystem.DialogueSystem::Begin()
extern void DialogueSystem_Begin_m087D743F902C6987CCFC0FB51648BB8D229734E7 (void);
// 0x0000018F System.Void KyleSystem.DialogueSystem.DialogueSystem::End()
extern void DialogueSystem_End_mFD428BBA15F6F87B09C88CAB0F28D97EDE06684A (void);
// 0x00000190 System.Void KyleSystem.DialogueSystem.DialogueSystem::Save()
extern void DialogueSystem_Save_mA794CB256547BA8E376898EA4DBD971552F1C6FF (void);
// 0x00000191 System.Void KyleSystem.DialogueSystem.DialogueSystem::Load()
extern void DialogueSystem_Load_m1E09E04E39904DC450BB0DCA589100053F973438 (void);
// 0x00000192 System.Void KyleSystem.DialogueSystem.DialogueSystem::.cctor()
extern void DialogueSystem__cctor_m16FAD7DF6490DE12D8239DDD98DA81977EE0C13A (void);
// 0x00000193 System.Void KyleSystem.DialogueSystem.DialogueScene::.ctor(System.String)
extern void DialogueScene__ctor_mE73977AE531F8923C3893CE05A7899A5D651A338 (void);
// 0x00000194 System.Void KyleSystem.DialogueSystem.DialoguePackage::.ctor(KyleSystem.DialogueSystem.DialogueLine,System.Collections.Generic.List`1<KyleSystem.DialogueSystem.DialogueAnimation>)
extern void DialoguePackage__ctor_mAF58F1F68828DCEDBA2BC11A6493AD4293D036DF (void);
// 0x00000195 System.Void KyleSystem.DialogueSystem.DialogueAnimation::.ctor(System.Int32,System.String)
extern void DialogueAnimation__ctor_mBA600C2860EA7EC662C06932725D1B2C345CC79E (void);
// 0x00000196 System.Void KyleSystem.DialogueSystem.DialogueLine::.ctor(System.String,System.String,System.Single)
extern void DialogueLine__ctor_mB386FE7E0F3B0F65052AF4EE009AD50396445029 (void);
// 0x00000197 KyleSystem.Characters.Character KyleSystem.Characters.CharacterAnimator::get_cur()
extern void CharacterAnimator_get_cur_m12CA24AA25328F3704D753C5EFE45FF7DB3A11F3 (void);
// 0x00000198 KyleSystem.Characters.CharacterAnimation KyleSystem.Characters.CharacterAnimator::get_anim()
extern void CharacterAnimator_get_anim_mC6BE709BCED9B65E6331E1A5793CF620C805B0D8 (void);
// 0x00000199 UnityEngine.Sprite KyleSystem.Characters.CharacterAnimator::get_curFrame()
extern void CharacterAnimator_get_curFrame_mC0511596444F5F5BEBB1B82EEBEED9FA09E1D1CC (void);
// 0x0000019A System.Void KyleSystem.Characters.CharacterAnimator::Start()
extern void CharacterAnimator_Start_m31DD092D8255D5B5A82B9635DD77CB60B18B98E1 (void);
// 0x0000019B System.Void KyleSystem.Characters.CharacterAnimator::SignOn(System.Int32)
extern void CharacterAnimator_SignOn_m0AD9ECE0C5B8AEF37A3B23E16282A8BF3A4FD26C (void);
// 0x0000019C System.Void KyleSystem.Characters.CharacterAnimator::SignOff(System.Int32)
extern void CharacterAnimator_SignOff_m5E532782C5FDC2A48B29CC265B907FE28120BDDD (void);
// 0x0000019D System.Void KyleSystem.Characters.CharacterAnimator::Update()
extern void CharacterAnimator_Update_m18E88FBBC03D510434FDC4FDCC798463B1B00DB1 (void);
// 0x0000019E System.Void KyleSystem.Characters.CharacterAnimator::OnEnable()
extern void CharacterAnimator_OnEnable_m49F25DA12A666922C3DF50FFE46E26CB40B60F13 (void);
// 0x0000019F System.Void KyleSystem.Characters.CharacterAnimator::OnDestroy()
extern void CharacterAnimator_OnDestroy_m5BF728F7F0F6D7405C034244ED1AEB5954E1895F (void);
// 0x000001A0 System.Void KyleSystem.Characters.CharacterAnimator::.ctor()
extern void CharacterAnimator__ctor_m1ED19457E2F75BE8EC72C5335985CC8661903E24 (void);
// 0x000001A1 System.Void KyleSystem.Characters.CharacterListLoader::Start()
extern void CharacterListLoader_Start_m3A943AE87B7EAC777284826D7FFCE7B8031C6F3F (void);
// 0x000001A2 System.Collections.IEnumerator KyleSystem.Characters.CharacterListLoader::RegularCleaning()
extern void CharacterListLoader_RegularCleaning_mFF8BB3F3CAD3CAF1401D8300DD25C7D9CB89CE58 (void);
// 0x000001A3 System.Void KyleSystem.Characters.CharacterListLoader::.ctor()
extern void CharacterListLoader__ctor_m0A0BEC21D030433FE30ACB03522837F428209A67 (void);
// 0x000001A4 System.Void KyleSystem.Characters.CharacterSystem::add_Saving(System.Action)
extern void CharacterSystem_add_Saving_mA78D70B6FA1205A5473365A0FEF808900ED9639F (void);
// 0x000001A5 System.Void KyleSystem.Characters.CharacterSystem::remove_Saving(System.Action)
extern void CharacterSystem_remove_Saving_m43B7C872E6BCF55F2EF83551588974B5AB94D4BD (void);
// 0x000001A6 System.Void KyleSystem.Characters.CharacterSystem::RandomBullshitGo()
extern void CharacterSystem_RandomBullshitGo_mEBB48C65A9142C3A95DAB4EE5571802A0B39E6BD (void);
// 0x000001A7 System.Void KyleSystem.Characters.CharacterSystem::Save()
extern void CharacterSystem_Save_m649CF4B9D7A2259E39D555F9F163DF016798C946 (void);
// 0x000001A8 System.Void KyleSystem.Characters.CharacterSystem::Load()
extern void CharacterSystem_Load_mEC48128AA3C5C34B62CE69E6B7D9A925E7D241A7 (void);
// 0x000001A9 System.Boolean KyleSystem.Characters.CharacterSystem::Exists()
extern void CharacterSystem_Exists_m2A9C8F1AC1747E7335C788B51C41D383A139E0A9 (void);
// 0x000001AA System.Void KyleSystem.Characters.CharacterSystem::Prepare()
extern void CharacterSystem_Prepare_mA5364A656E713186D00C5F3DFE49EB8D7B526C04 (void);
// 0x000001AB System.Void KyleSystem.Characters.CharacterSystem::LoadInChar(System.Int32)
extern void CharacterSystem_LoadInChar_mB684574FB0C29F88A194A75ACB90FA1E382FF32F (void);
// 0x000001AC System.Void KyleSystem.Characters.CharacterSystem::UnLoadChar(System.Int32)
extern void CharacterSystem_UnLoadChar_m32CA3D1A5B17B2236BFF7BD7FDB8A0047CCEC808 (void);
// 0x000001AD System.Void KyleSystem.Characters.CharacterSystem::CheckSignedOn()
extern void CharacterSystem_CheckSignedOn_mAC00DA19DACF24F58CA9B2A6BC11C3E305C52332 (void);
// 0x000001AE System.Void KyleSystem.Characters.CharacterSystem::CheckSignedOn(System.Int32)
extern void CharacterSystem_CheckSignedOn_mC1FFC28B89FA41477E42CFD72A1CF7D0D8194DA3 (void);
// 0x000001AF System.Void KyleSystem.Characters.CharacterSystem::.cctor()
extern void CharacterSystem__cctor_mA4162F084CDFC7CE54A9F0464CCED1522B1D137F (void);
// 0x000001B0 System.Void KyleSystem.Characters.Character::.ctor(System.String)
extern void Character__ctor_mE9DC2D041D5166A615FDF6996C65F27B34F55A64 (void);
// 0x000001B1 System.Int32 KyleSystem.Characters.Character::GetByName(System.String)
extern void Character_GetByName_m0DC9C8644EE7EEB9DA94B73BC72B19E5CFEFDD2D (void);
// 0x000001B2 System.Void KyleSystem.Characters.CharacterAnimation::.ctor(System.String,System.Single,System.Collections.Generic.List`1<UnityEngine.Sprite>)
extern void CharacterAnimation__ctor_m4B3B3A994CE5D1BAE20ADC3FCC4AE97B251F0810 (void);
// 0x000001B3 System.Void KyleSystem.Characters.CharacterAnimation::.ctor(System.String,System.Single,System.Collections.Generic.List`1<UnityEngine.Sprite>,System.Boolean)
extern void CharacterAnimation__ctor_m500E115A287B82898B5D8CAD2D9B2C797300DDB2 (void);
// 0x000001B4 System.Void KyleSystem.Characters.CharacterAnimation::SaveToReference()
extern void CharacterAnimation_SaveToReference_m83F76E2E6E3DE6BB17A1B21F75A9345D34D7B21B (void);
// 0x000001B5 System.Void KyleSystem.Characters.CharacterAnimation::LoadFromReference()
extern void CharacterAnimation_LoadFromReference_mE493DD6459D7F6E5A6D97CD7F9454A898EB462A3 (void);
// 0x000001B6 System.String KyleSystem.Characters.CharacterAnimation::RemoveUntilResources(System.String)
extern void CharacterAnimation_RemoveUntilResources_m3358F09EEF5CEA51562E98D2F65FE5235E9AA300 (void);
// 0x000001B7 System.Void KyleSystem.Characters.SpriteReferences::.ctor(System.String[])
extern void SpriteReferences__ctor_mD204383C8F38153FD60B335292C7B27AD24FC90E (void);
// 0x000001B8 System.Void FadeEffect_<MoveTo>d__11::.ctor(System.Int32)
extern void U3CMoveToU3Ed__11__ctor_m28B22E6C0A568D7533208F59139E9C45FEFA311C (void);
// 0x000001B9 System.Void FadeEffect_<MoveTo>d__11::System.IDisposable.Dispose()
extern void U3CMoveToU3Ed__11_System_IDisposable_Dispose_mCE1E98BCA6EA4A273CF019515D1FD6BD1C8B9487 (void);
// 0x000001BA System.Boolean FadeEffect_<MoveTo>d__11::MoveNext()
extern void U3CMoveToU3Ed__11_MoveNext_m643C64B9928299FBD1E27BBB4E1A44284F439F00 (void);
// 0x000001BB System.Object FadeEffect_<MoveTo>d__11::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CMoveToU3Ed__11_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mEFB3D7120DB826D86464D3D7447BA06D1DC6DA52 (void);
// 0x000001BC System.Void FadeEffect_<MoveTo>d__11::System.Collections.IEnumerator.Reset()
extern void U3CMoveToU3Ed__11_System_Collections_IEnumerator_Reset_m900236E771105AFCD0838EFF9C945FAA333CF926 (void);
// 0x000001BD System.Object FadeEffect_<MoveTo>d__11::System.Collections.IEnumerator.get_Current()
extern void U3CMoveToU3Ed__11_System_Collections_IEnumerator_get_Current_m9B36F54FFF3F948092A2EC15F90928BA78523F02 (void);
// 0x000001BE System.Void RoomSystem_<FreezeTime>d__25::.ctor(System.Int32)
extern void U3CFreezeTimeU3Ed__25__ctor_mE8D750D103495C0D90552BE10BB42B9818577C24 (void);
// 0x000001BF System.Void RoomSystem_<FreezeTime>d__25::System.IDisposable.Dispose()
extern void U3CFreezeTimeU3Ed__25_System_IDisposable_Dispose_m1005A4A74AA407FB453DB0A12559ED090290BCE5 (void);
// 0x000001C0 System.Boolean RoomSystem_<FreezeTime>d__25::MoveNext()
extern void U3CFreezeTimeU3Ed__25_MoveNext_mF524CB963935C801C450C0A98F55D8AA2A5EC24E (void);
// 0x000001C1 System.Object RoomSystem_<FreezeTime>d__25::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CFreezeTimeU3Ed__25_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mBA81A6D214ABA0E876A4A1571E59DE8544735291 (void);
// 0x000001C2 System.Void RoomSystem_<FreezeTime>d__25::System.Collections.IEnumerator.Reset()
extern void U3CFreezeTimeU3Ed__25_System_Collections_IEnumerator_Reset_mD4F3156E71D7510901D0942FA7ACD294CFE05A29 (void);
// 0x000001C3 System.Object RoomSystem_<FreezeTime>d__25::System.Collections.IEnumerator.get_Current()
extern void U3CFreezeTimeU3Ed__25_System_Collections_IEnumerator_get_Current_mC9E814CC791A3CAE03CE2432D165E0BAE378EA1E (void);
// 0x000001C4 System.Void Chapter1Intro_<AAAAAAAA>d__5::.ctor(System.Int32)
extern void U3CAAAAAAAAU3Ed__5__ctor_m656595BCEEB9A1F00955BE77173C5ECFFBC94A0D (void);
// 0x000001C5 System.Void Chapter1Intro_<AAAAAAAA>d__5::System.IDisposable.Dispose()
extern void U3CAAAAAAAAU3Ed__5_System_IDisposable_Dispose_m69ED5822F7DAEC04D263F496AD8A9070AF5ED4D6 (void);
// 0x000001C6 System.Boolean Chapter1Intro_<AAAAAAAA>d__5::MoveNext()
extern void U3CAAAAAAAAU3Ed__5_MoveNext_m2CE8CAD00222F1D3B8C7F6141BB482379448C9D4 (void);
// 0x000001C7 System.Object Chapter1Intro_<AAAAAAAA>d__5::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CAAAAAAAAU3Ed__5_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m8B36C63B19C40D0219BEC6140633D96B24365495 (void);
// 0x000001C8 System.Void Chapter1Intro_<AAAAAAAA>d__5::System.Collections.IEnumerator.Reset()
extern void U3CAAAAAAAAU3Ed__5_System_Collections_IEnumerator_Reset_m23CBEEF99AB059B222A76DED4431570284A3E15B (void);
// 0x000001C9 System.Object Chapter1Intro_<AAAAAAAA>d__5::System.Collections.IEnumerator.get_Current()
extern void U3CAAAAAAAAU3Ed__5_System_Collections_IEnumerator_get_Current_mB96FABC6B0E8CB10457374A905CEBAD03EAB0AF2 (void);
// 0x000001CA System.Void MarbleCollectable_<WaitForRoomSystem>d__17::.ctor(System.Int32)
extern void U3CWaitForRoomSystemU3Ed__17__ctor_m8E4328143EFD4A5C3026717F2AFD3229E926BD4F (void);
// 0x000001CB System.Void MarbleCollectable_<WaitForRoomSystem>d__17::System.IDisposable.Dispose()
extern void U3CWaitForRoomSystemU3Ed__17_System_IDisposable_Dispose_mA67C767AC3CF877CFE0EA952FAA457F89B20E03E (void);
// 0x000001CC System.Boolean MarbleCollectable_<WaitForRoomSystem>d__17::MoveNext()
extern void U3CWaitForRoomSystemU3Ed__17_MoveNext_m95EFA54ED84A113787F0BA7139D2BF8B922C1945 (void);
// 0x000001CD System.Object MarbleCollectable_<WaitForRoomSystem>d__17::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CWaitForRoomSystemU3Ed__17_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mE0262488EA2C5EA3F5B40D6013C1360C3FE9D82A (void);
// 0x000001CE System.Void MarbleCollectable_<WaitForRoomSystem>d__17::System.Collections.IEnumerator.Reset()
extern void U3CWaitForRoomSystemU3Ed__17_System_Collections_IEnumerator_Reset_m7BF2BE14C3B8F153BC8049690AAC33CCA91D7B92 (void);
// 0x000001CF System.Object MarbleCollectable_<WaitForRoomSystem>d__17::System.Collections.IEnumerator.get_Current()
extern void U3CWaitForRoomSystemU3Ed__17_System_Collections_IEnumerator_get_Current_m2A5E08D591CB96C144B08516FB1044381F00A6B9 (void);
// 0x000001D0 System.Void MarbleCollectable_<Follow>d__19::.ctor(System.Int32)
extern void U3CFollowU3Ed__19__ctor_m7C0E668F5A8F755D49CD9CDDB9FC932E06819748 (void);
// 0x000001D1 System.Void MarbleCollectable_<Follow>d__19::System.IDisposable.Dispose()
extern void U3CFollowU3Ed__19_System_IDisposable_Dispose_mAE3A090E6530E0641C47139985CB8978A3B9CC58 (void);
// 0x000001D2 System.Boolean MarbleCollectable_<Follow>d__19::MoveNext()
extern void U3CFollowU3Ed__19_MoveNext_mB799E50B40C228527B78AB57AF485646BDC93C8A (void);
// 0x000001D3 System.Object MarbleCollectable_<Follow>d__19::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CFollowU3Ed__19_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m9A4270D31C5301CB9BCF04ECC7FC054665DB7722 (void);
// 0x000001D4 System.Void MarbleCollectable_<Follow>d__19::System.Collections.IEnumerator.Reset()
extern void U3CFollowU3Ed__19_System_Collections_IEnumerator_Reset_m6C5C19D171CF83F6AD628BF6153A18946AA8EBE3 (void);
// 0x000001D5 System.Object MarbleCollectable_<Follow>d__19::System.Collections.IEnumerator.get_Current()
extern void U3CFollowU3Ed__19_System_Collections_IEnumerator_get_Current_mF634E7AD7826C83C374D564BC44ED70A79F46A31 (void);
// 0x000001D6 System.Void MarbleCollectable_<CheckDelete>d__30::.ctor(System.Int32)
extern void U3CCheckDeleteU3Ed__30__ctor_mB81324F704652F0816682C4BAB6388B016FD1322 (void);
// 0x000001D7 System.Void MarbleCollectable_<CheckDelete>d__30::System.IDisposable.Dispose()
extern void U3CCheckDeleteU3Ed__30_System_IDisposable_Dispose_mF89E5D423096C655702101DABFDC686D4B64A3D0 (void);
// 0x000001D8 System.Boolean MarbleCollectable_<CheckDelete>d__30::MoveNext()
extern void U3CCheckDeleteU3Ed__30_MoveNext_mD35B95252F24F7349B8660B703B2E4EF2379E5EF (void);
// 0x000001D9 System.Object MarbleCollectable_<CheckDelete>d__30::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CCheckDeleteU3Ed__30_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m38D000D772779BC7C745743DE1F426CF156188BD (void);
// 0x000001DA System.Void MarbleCollectable_<CheckDelete>d__30::System.Collections.IEnumerator.Reset()
extern void U3CCheckDeleteU3Ed__30_System_Collections_IEnumerator_Reset_m8A7618CFE83ECF44E0476E59F828395FBEBB9FD2 (void);
// 0x000001DB System.Object MarbleCollectable_<CheckDelete>d__30::System.Collections.IEnumerator.get_Current()
extern void U3CCheckDeleteU3Ed__30_System_Collections_IEnumerator_get_Current_mF2BCD757F4BDEF9126FB4EA1FAF15736F6D79118 (void);
// 0x000001DC System.Void Progress_<FadeIntoNextChapter>d__10::.ctor(System.Int32)
extern void U3CFadeIntoNextChapterU3Ed__10__ctor_m6F02F4D82320D3B9A8EE69B8852B4345EC6B40BD (void);
// 0x000001DD System.Void Progress_<FadeIntoNextChapter>d__10::System.IDisposable.Dispose()
extern void U3CFadeIntoNextChapterU3Ed__10_System_IDisposable_Dispose_m39C3FCE8F5479A67349C0E29ECD60630C70546E3 (void);
// 0x000001DE System.Boolean Progress_<FadeIntoNextChapter>d__10::MoveNext()
extern void U3CFadeIntoNextChapterU3Ed__10_MoveNext_m5047B7F0C8AFD23439B77EE41733135E04C6D76F (void);
// 0x000001DF System.Object Progress_<FadeIntoNextChapter>d__10::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CFadeIntoNextChapterU3Ed__10_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m8291835935B211B26EB45AC0932E007DF389217F (void);
// 0x000001E0 System.Void Progress_<FadeIntoNextChapter>d__10::System.Collections.IEnumerator.Reset()
extern void U3CFadeIntoNextChapterU3Ed__10_System_Collections_IEnumerator_Reset_mEB414BB3C423024F9A094EAD26CB7A200B663DCC (void);
// 0x000001E1 System.Object Progress_<FadeIntoNextChapter>d__10::System.Collections.IEnumerator.get_Current()
extern void U3CFadeIntoNextChapterU3Ed__10_System_Collections_IEnumerator_get_Current_mBA68FD81E7E3FE6AC3B111B30EE58D329B5536F0 (void);
// 0x000001E2 System.Void Progress_<>c__DisplayClass12_0::.ctor()
extern void U3CU3Ec__DisplayClass12_0__ctor_m32ADD498CBC86F5B24FF6924A16AE3D711971027 (void);
// 0x000001E3 System.Void Progress_<>c__DisplayClass12_0::<SetPlayerToPosition>b__1(UnityEngine.AsyncOperation)
extern void U3CU3Ec__DisplayClass12_0_U3CSetPlayerToPositionU3Eb__1_m0ED1FF0D11E54429404B025156FD8F1A7B1ADA01 (void);
// 0x000001E4 System.Void Progress_<>c::.cctor()
extern void U3CU3Ec__cctor_mC58D280F3E75566442D14F11105BECF7AA561466 (void);
// 0x000001E5 System.Void Progress_<>c::.ctor()
extern void U3CU3Ec__ctor_m44BD61E15C2487E25DD09E1485AAE9218C022AA5 (void);
// 0x000001E6 System.Void Progress_<>c::<SetPlayerToPosition>b__12_0(UnityEngine.AsyncOperation)
extern void U3CU3Ec_U3CSetPlayerToPositionU3Eb__12_0_m1CC1079B7B758C12A9136320EB86549E74EAE153 (void);
// 0x000001E7 System.Void EndCutscene_<<BeginCutScene>g__WaitTilTheEndU7C0_0>d::.ctor(System.Int32)
extern void U3CU3CBeginCutSceneU3Eg__WaitTilTheEndU7C0_0U3Ed__ctor_mAA0C0256BFB9BF1A1D481307E9F41506C160D6EA (void);
// 0x000001E8 System.Void EndCutscene_<<BeginCutScene>g__WaitTilTheEndU7C0_0>d::System.IDisposable.Dispose()
extern void U3CU3CBeginCutSceneU3Eg__WaitTilTheEndU7C0_0U3Ed_System_IDisposable_Dispose_m70B977CC33A188CF98091DC2F22434937FC94D22 (void);
// 0x000001E9 System.Boolean EndCutscene_<<BeginCutScene>g__WaitTilTheEndU7C0_0>d::MoveNext()
extern void U3CU3CBeginCutSceneU3Eg__WaitTilTheEndU7C0_0U3Ed_MoveNext_mDF4F9771070977AD5C5C68B5445151BBA6F4DAF2 (void);
// 0x000001EA System.Object EndCutscene_<<BeginCutScene>g__WaitTilTheEndU7C0_0>d::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CU3CBeginCutSceneU3Eg__WaitTilTheEndU7C0_0U3Ed_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mE1CE180DA3E4AC0E48789937DA33DDF6D7F09293 (void);
// 0x000001EB System.Void EndCutscene_<<BeginCutScene>g__WaitTilTheEndU7C0_0>d::System.Collections.IEnumerator.Reset()
extern void U3CU3CBeginCutSceneU3Eg__WaitTilTheEndU7C0_0U3Ed_System_Collections_IEnumerator_Reset_m71C20905DFE610DC763C98490328DC3017AD0205 (void);
// 0x000001EC System.Object EndCutscene_<<BeginCutScene>g__WaitTilTheEndU7C0_0>d::System.Collections.IEnumerator.get_Current()
extern void U3CU3CBeginCutSceneU3Eg__WaitTilTheEndU7C0_0U3Ed_System_Collections_IEnumerator_get_Current_m1196321B7897D9FDEB6C76F13B08AC8FCC5DA74E (void);
// 0x000001ED System.Void CloudTree_<WaitABit>d__10::.ctor(System.Int32)
extern void U3CWaitABitU3Ed__10__ctor_mC0CABE565DBD54F31655490EDCFD8341BDADA118 (void);
// 0x000001EE System.Void CloudTree_<WaitABit>d__10::System.IDisposable.Dispose()
extern void U3CWaitABitU3Ed__10_System_IDisposable_Dispose_mC875AC1F6FCA0F715CD85503530FF68F63709AD9 (void);
// 0x000001EF System.Boolean CloudTree_<WaitABit>d__10::MoveNext()
extern void U3CWaitABitU3Ed__10_MoveNext_mA2693546853832CFD4D71C20EA3D35D716A7B37B (void);
// 0x000001F0 System.Object CloudTree_<WaitABit>d__10::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CWaitABitU3Ed__10_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mD879299E6A0480BA3AA6FB6710D816FE3476348E (void);
// 0x000001F1 System.Void CloudTree_<WaitABit>d__10::System.Collections.IEnumerator.Reset()
extern void U3CWaitABitU3Ed__10_System_Collections_IEnumerator_Reset_mA4F6D416D50D490362175E76C1363FB0B1170DE4 (void);
// 0x000001F2 System.Object CloudTree_<WaitABit>d__10::System.Collections.IEnumerator.get_Current()
extern void U3CWaitABitU3Ed__10_System_Collections_IEnumerator_get_Current_m02E2C7E22098830990491312AB257814FAF95177 (void);
// 0x000001F3 System.Void Scrunge_DebugRay::.ctor(UnityEngine.Vector2,UnityEngine.Vector2,System.Single)
extern void DebugRay__ctor_m71C29A96CE1DB23E71EDD45B72D61D680FC92C2A (void);
// 0x000001F4 System.Void Conjunctor_<WaitForSpriteRenderer>d__3::.ctor(System.Int32)
extern void U3CWaitForSpriteRendererU3Ed__3__ctor_mA64E4D48606C4F45AEC0B14ACB75F928239CFC3C (void);
// 0x000001F5 System.Void Conjunctor_<WaitForSpriteRenderer>d__3::System.IDisposable.Dispose()
extern void U3CWaitForSpriteRendererU3Ed__3_System_IDisposable_Dispose_mDFB66E4A0DCD8A8537F34AE3644CAA89D695DB79 (void);
// 0x000001F6 System.Boolean Conjunctor_<WaitForSpriteRenderer>d__3::MoveNext()
extern void U3CWaitForSpriteRendererU3Ed__3_MoveNext_m424650EB1D8B632A5EB79AE2A7A410DEAF53C3B7 (void);
// 0x000001F7 System.Object Conjunctor_<WaitForSpriteRenderer>d__3::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CWaitForSpriteRendererU3Ed__3_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m7B27ED329C1FF5A2E2F073C1CBA2E91B90F73BDA (void);
// 0x000001F8 System.Void Conjunctor_<WaitForSpriteRenderer>d__3::System.Collections.IEnumerator.Reset()
extern void U3CWaitForSpriteRendererU3Ed__3_System_Collections_IEnumerator_Reset_mF6C9DE3A1E4E0C3F4BBF3D6A7993881F035F02EE (void);
// 0x000001F9 System.Object Conjunctor_<WaitForSpriteRenderer>d__3::System.Collections.IEnumerator.get_Current()
extern void U3CWaitForSpriteRendererU3Ed__3_System_Collections_IEnumerator_get_Current_m8B915BC776DE696F82384D531F0F3A1BA04D8B19 (void);
// 0x000001FA System.Void PlayerControl_DebugRay::.ctor(UnityEngine.Vector2,UnityEngine.Vector2,System.Single)
extern void DebugRay__ctor_mA99D3FE99AD6CF0D4E8751DF340FDCCE421D8BD0 (void);
// 0x000001FB System.Void ReturnByDeath_<WaitForDeathToEnd>d__8::.ctor(System.Int32)
extern void U3CWaitForDeathToEndU3Ed__8__ctor_m164D9231AFC44C59DCC209391B730D2282B53447 (void);
// 0x000001FC System.Void ReturnByDeath_<WaitForDeathToEnd>d__8::System.IDisposable.Dispose()
extern void U3CWaitForDeathToEndU3Ed__8_System_IDisposable_Dispose_mBA32A32030200A779B7D7FCAC7E0E993242D25A3 (void);
// 0x000001FD System.Boolean ReturnByDeath_<WaitForDeathToEnd>d__8::MoveNext()
extern void U3CWaitForDeathToEndU3Ed__8_MoveNext_m2017755B3B6ED8DAC9A4430B50D5E29379B23596 (void);
// 0x000001FE System.Object ReturnByDeath_<WaitForDeathToEnd>d__8::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CWaitForDeathToEndU3Ed__8_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m9EB154986823BE4A11E2EE578ADA2CDA26291130 (void);
// 0x000001FF System.Void ReturnByDeath_<WaitForDeathToEnd>d__8::System.Collections.IEnumerator.Reset()
extern void U3CWaitForDeathToEndU3Ed__8_System_Collections_IEnumerator_Reset_m10549E2EF220D3C67C9398A496E5EDFF9658681E (void);
// 0x00000200 System.Object ReturnByDeath_<WaitForDeathToEnd>d__8::System.Collections.IEnumerator.get_Current()
extern void U3CWaitForDeathToEndU3Ed__8_System_Collections_IEnumerator_get_Current_m0C3DABE3A0A2001E4CEC715572B4C1C8A1F494A3 (void);
// 0x00000201 System.Void Wielder_<VelocityControl>d__24::.ctor(System.Int32)
extern void U3CVelocityControlU3Ed__24__ctor_mA7D49A9E638E0818A671216C92B9698919E23356 (void);
// 0x00000202 System.Void Wielder_<VelocityControl>d__24::System.IDisposable.Dispose()
extern void U3CVelocityControlU3Ed__24_System_IDisposable_Dispose_m9AD3848000B79F45FB17EF8DCD7C2FCDF30A5B68 (void);
// 0x00000203 System.Boolean Wielder_<VelocityControl>d__24::MoveNext()
extern void U3CVelocityControlU3Ed__24_MoveNext_mB5AD235033FFD49B25D72D2CB0657EE991D79E9E (void);
// 0x00000204 System.Object Wielder_<VelocityControl>d__24::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CVelocityControlU3Ed__24_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m9CEC7E5CB5F7D6512BA931970592442D47E45D8C (void);
// 0x00000205 System.Void Wielder_<VelocityControl>d__24::System.Collections.IEnumerator.Reset()
extern void U3CVelocityControlU3Ed__24_System_Collections_IEnumerator_Reset_m500784131834CEDCA798C55294716756BB23D7E3 (void);
// 0x00000206 System.Object Wielder_<VelocityControl>d__24::System.Collections.IEnumerator.get_Current()
extern void U3CVelocityControlU3Ed__24_System_Collections_IEnumerator_get_Current_m96555EFE651E349B2FEE95A79292CD8C993FCEBB (void);
// 0x00000207 System.Void Chapter0CutScene_<MovePlayer>d__3::.ctor(System.Int32)
extern void U3CMovePlayerU3Ed__3__ctor_m5627BE7C5A79C6C16BFC8FCECBBD8E684E8885AC (void);
// 0x00000208 System.Void Chapter0CutScene_<MovePlayer>d__3::System.IDisposable.Dispose()
extern void U3CMovePlayerU3Ed__3_System_IDisposable_Dispose_mE5A29E5AE65C44B6200F9EAD20F6D4F53F89E362 (void);
// 0x00000209 System.Boolean Chapter0CutScene_<MovePlayer>d__3::MoveNext()
extern void U3CMovePlayerU3Ed__3_MoveNext_m0F18E5BD91C70C6E0EF1F9606CA6E037F25210E9 (void);
// 0x0000020A System.Object Chapter0CutScene_<MovePlayer>d__3::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CMovePlayerU3Ed__3_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m96686D17D6569A951A142356B04B68D23611063D (void);
// 0x0000020B System.Void Chapter0CutScene_<MovePlayer>d__3::System.Collections.IEnumerator.Reset()
extern void U3CMovePlayerU3Ed__3_System_Collections_IEnumerator_Reset_m46EFCD65AE33249935241D8AC9C13B7873D41518 (void);
// 0x0000020C System.Object Chapter0CutScene_<MovePlayer>d__3::System.Collections.IEnumerator.get_Current()
extern void U3CMovePlayerU3Ed__3_System_Collections_IEnumerator_get_Current_m80EF404750032AC6AC2498A60C65F94723F3E1FC (void);
// 0x0000020D System.Void GoNextChapter_<<Thing>g__waitForFadeU7C2_0>d::.ctor(System.Int32)
extern void U3CU3CThingU3Eg__waitForFadeU7C2_0U3Ed__ctor_m985622B5CD38C2860E6F3F188A9D1433B3157675 (void);
// 0x0000020E System.Void GoNextChapter_<<Thing>g__waitForFadeU7C2_0>d::System.IDisposable.Dispose()
extern void U3CU3CThingU3Eg__waitForFadeU7C2_0U3Ed_System_IDisposable_Dispose_m4A193F633B76B63BDCC81FACEA6216B70A768A17 (void);
// 0x0000020F System.Boolean GoNextChapter_<<Thing>g__waitForFadeU7C2_0>d::MoveNext()
extern void U3CU3CThingU3Eg__waitForFadeU7C2_0U3Ed_MoveNext_m1ED0F153DAEAE79B14B61DF0B6B44F37F84DA406 (void);
// 0x00000210 System.Object GoNextChapter_<<Thing>g__waitForFadeU7C2_0>d::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CU3CThingU3Eg__waitForFadeU7C2_0U3Ed_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m0C5C5DEE628C1B7FC64FD7E5321433DFA637AC2C (void);
// 0x00000211 System.Void GoNextChapter_<<Thing>g__waitForFadeU7C2_0>d::System.Collections.IEnumerator.Reset()
extern void U3CU3CThingU3Eg__waitForFadeU7C2_0U3Ed_System_Collections_IEnumerator_Reset_mA797439FB1BCD1B12A57A5E615AEBB90E4CC6681 (void);
// 0x00000212 System.Object GoNextChapter_<<Thing>g__waitForFadeU7C2_0>d::System.Collections.IEnumerator.get_Current()
extern void U3CU3CThingU3Eg__waitForFadeU7C2_0U3Ed_System_Collections_IEnumerator_get_Current_mEEC76A4C951B38ACC0B4E1C67DC9BB07848E1B86 (void);
// 0x00000213 System.Void KyleSystem.DialogueSystem.DialogueListener_<DialogueTimer>d__8::.ctor(System.Int32)
extern void U3CDialogueTimerU3Ed__8__ctor_mF57CA110C4BA67709F2D23B285C515699AD93DBD (void);
// 0x00000214 System.Void KyleSystem.DialogueSystem.DialogueListener_<DialogueTimer>d__8::System.IDisposable.Dispose()
extern void U3CDialogueTimerU3Ed__8_System_IDisposable_Dispose_m2F9AF8E0887D0A92373EB07B2F1845CA6F9384C8 (void);
// 0x00000215 System.Boolean KyleSystem.DialogueSystem.DialogueListener_<DialogueTimer>d__8::MoveNext()
extern void U3CDialogueTimerU3Ed__8_MoveNext_mD3D8D8F1B5F82CD9FCBD315313AF0F72CAF4D949 (void);
// 0x00000216 System.Object KyleSystem.DialogueSystem.DialogueListener_<DialogueTimer>d__8::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CDialogueTimerU3Ed__8_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m96040DAD6EAF9322D05B4D52D18F74B600B7F236 (void);
// 0x00000217 System.Void KyleSystem.DialogueSystem.DialogueListener_<DialogueTimer>d__8::System.Collections.IEnumerator.Reset()
extern void U3CDialogueTimerU3Ed__8_System_Collections_IEnumerator_Reset_mE3A557C7558847B80A8FBAC2006E2AD5C3B3C2E5 (void);
// 0x00000218 System.Object KyleSystem.DialogueSystem.DialogueListener_<DialogueTimer>d__8::System.Collections.IEnumerator.get_Current()
extern void U3CDialogueTimerU3Ed__8_System_Collections_IEnumerator_get_Current_m5645CE4B56F1F657ED1F46BC8BD3FA96DE5617B7 (void);
// 0x00000219 System.Void KyleSystem.Characters.CharacterListLoader_<RegularCleaning>d__1::.ctor(System.Int32)
extern void U3CRegularCleaningU3Ed__1__ctor_m80E4158D4E119C2B5C79BE8C8D3177A167805813 (void);
// 0x0000021A System.Void KyleSystem.Characters.CharacterListLoader_<RegularCleaning>d__1::System.IDisposable.Dispose()
extern void U3CRegularCleaningU3Ed__1_System_IDisposable_Dispose_mEC933010285B4E31D7A595DB4FC76A3FD0D484DB (void);
// 0x0000021B System.Boolean KyleSystem.Characters.CharacterListLoader_<RegularCleaning>d__1::MoveNext()
extern void U3CRegularCleaningU3Ed__1_MoveNext_mE388E4C5C26DCADB4DE3FB467D83E9E3223774F9 (void);
// 0x0000021C System.Object KyleSystem.Characters.CharacterListLoader_<RegularCleaning>d__1::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CRegularCleaningU3Ed__1_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m61026EDCB5BC5E3E99A8C238594EE59D26ADAD74 (void);
// 0x0000021D System.Void KyleSystem.Characters.CharacterListLoader_<RegularCleaning>d__1::System.Collections.IEnumerator.Reset()
extern void U3CRegularCleaningU3Ed__1_System_Collections_IEnumerator_Reset_m2AF6C343C87ABC966BD81241ADF0972A88655092 (void);
// 0x0000021E System.Object KyleSystem.Characters.CharacterListLoader_<RegularCleaning>d__1::System.Collections.IEnumerator.get_Current()
extern void U3CRegularCleaningU3Ed__1_System_Collections_IEnumerator_get_Current_m2A0728739DEBE60A6B26F03B4AF4B354BE92E1CC (void);
static Il2CppMethodPointer s_methodPointers[542] = 
{
	BackgroundHandler_Start_mB624DC7BB350A4DFA3A728259FD6919001B3A95A,
	BackgroundHandler_Update_mAE220C8BD5C3C37766E932910C8677A8FB067DA3,
	BackgroundHandler__ctor_m1D2CC73F6EF2E286DB763EAFDA6DE92A78E5CDA1,
	FadeEffect_get_covering_m063E5CC30EB59882B3E07BD2854ACEA20230A21A,
	FadeEffect_get_effectTransitioning_mA91FC993B0068B91136148F33F64B345796234D3,
	FadeEffect_Start_m7F6E600BAACD6D397341686F2177D3E26890C0D8,
	FadeEffect_FadeIn_m0F544E39C8B9FCD731BDE4B24DA0EB957DAF0BF4,
	FadeEffect_FadeOut_mA810209AE1BB5C88BD1B8A4D9E98649363097DF8,
	FadeEffect_MoveTo_mFB800729AAD540118C7A5D759C4E84742A24F10A,
	FadeEffect__ctor_m060B0A3CA23834F91E3B83C6EBA99B2B758B66A9,
	KCutScene_BeginCutScene_m58C3794AA9DD50F8431017940859807BD10923AF,
	KCutScene_EndCutScene_mF46271833BB768821AD7DD31D71526A07285086C,
	NULL,
	NULL,
	CutSceneData__ctor_m91C2796EDA5CF5506283D05EB02A5E7AADABBD7B,
	KObject_get_timeMove_m17526B1FEDD8FDA0B2E5082F42FB31794DFC278A,
	KObject_set_timeMove_m2BC49C9D0F59DCFB5F677EAD5B03D8D0B9A23B39,
	KObject_get_canFlow_m24A9A414925E31DFC8EF538D0CE68CF2778AD784,
	KObject_add_SaveSelves_m1744837D5F488EF9E3E9D38DF85C5881ADADAAD5,
	KObject_remove_SaveSelves_mB4F9160504C9912E9D25D7BB5A4C317B003E8258,
	KObject_add_LoadSelves_mD932D7101ECECD186F4F35494D9BADCFB65B99C1,
	KObject_remove_LoadSelves_mF0896C17AB6DCF1A687791B5982D29DD6E353CBF,
	KObject_ResetTime_m6019E95D7257D06D7D47C1A2D2D311AA5924CA88,
	KObject_Start_m9B82D20AB4B53D04D3FFD2A1C8CBA013777416A3,
	KObject_OnDestroy_mEFC50724B5784333B813F2BB61BD1312FD87A057,
	KObject_Update_mD8A3CA5719C4832B23CFC224850CE7BED44FDC86,
	KObject_LateUpdate_m13B5D45A30CAD51DEBCE6A4974EEF8C8AA4148D5,
	KObject_KUpdate_mA6ABBF002C94174B8CA42B925DE2598DC34E4D74,
	KObject_KLateUpdate_mF4AE6C9E935CEF1B689B30DD0BC36778DF5212C4,
	KObject_KLateUpdateImageEffect_mCE144C599388E69DA3C386EA9B495130E53560B7,
	KObject_SaveData_mF35102A7F6C03A03E1CF62E7183BDFD1361B09FB,
	KObject_LoadData_mDCA241EA24D2803A1BD7B9B0587B3332BCA6C99B,
	KObject_LoadAll_m37CD5EB4FEF7D584C6200A9ECEEE454486878775,
	KObject__ctor_m4B75440D34D31FD51FE36D86D911E0D533FE5B4E,
	KObject__cctor_m8553FE11E4FB4BBCD92F11E1E46F52731AE48F68,
	BackToBase_SelectMethod_mB971BBF2535DCE189245CB89F2C55D28495A3C26,
	BackToBase__ctor_mF878523827DEEE64C71C3F37A002D64863667A12,
	Continue_SelectMethod_m5AF9E05312EBF0B48E9E5B0766583FF7F501ED12,
	Continue__ctor_mB5A1FA33CE2A1D1A1BDCFE942FF6B213F02AD625,
	ContinueGame_SelectMethod_m72431D869BA1CE684B630865CE9EEF4AEB054414,
	ContinueGame_MenuUpdate_m8BCEC0DE2377FCAA3581C7A31AF8835807D66839,
	ContinueGame__ctor_m34FD560A24F4EAB815C0057041F6E796ABFDC1A0,
	FileSelect_SelectMethod_mF430DA2EAB53937222FF07CB78145D28633E06FE,
	FileSelect_MenuUpdate_m283407DCBCD20D592F0F5E5DF6C0764B9E0228C4,
	FileSelect__ctor_m3537E2D5D3226E8A2C4105B7B2D668B51A722713,
	FullscreenToggle_SelectMethod_m4C9543110AB4DD9731369E925EBF3F9E3837C4A2,
	FullscreenToggle_MenuUpdate_mC7C3B2EFECE901B8ECA59DC78CB56F8EF3646C70,
	FullscreenToggle__ctor_m76F2F8D97C7288A07671D3E117612C193DBC18E8,
	MainMenu_SelectMethod_m11F1F7C29C5D9DDFA1F10B5CE494AE7309C337E3,
	MainMenu__ctor_m63F945D965550BD614DCD2AE7F7489D4F28C5B30,
	NewGame_SelectMethod_m8E5646A7169E77E327562F7DE3E0A2EBA2D5839A,
	NewGame__ctor_mEEFA222781A9319B278E4A7BAF3BBE1DD124B8BA,
	Options_SelectMethod_m5957E324D9AA133756D930201E0828DE95F2ECDA,
	Options__ctor_mAE411B1BD3EA4C02BE8C21D8A7C7141302425063,
	Quit_SelectMethod_m76E38C22A6232B7235DBA581900FAADC1BBAF0C5,
	Quit__ctor_m4C50BF52D3A6ADB583BE76FE1DEAFB1C889B3F6A,
	Retry_SelectMethod_mDD597DE04CABAF2EA37178F32F932F269EDD3F02,
	Retry_MenuUpdate_mEBBDF4251F4AE19ADF43183BB87F7FDCF585E69B,
	Retry__ctor_m3DB641DAFC3773EFF214851FF19378A9ED013851,
	SfxChange_SelectMethod_m0973307A068C4366324117D2B75918AF61DA0932,
	SfxChange_MenuUpdate_m3FBDA6709074319DF6ABCB72C4A7ABAA10D3C56F,
	SfxChange__ctor_m787160AD88200AE25BF62BD05EA6D3B477BB123A,
	SpeedrunToggle_SelectMethod_m075FB8C052A051CFEAD13CDB4C320AC7D806A24E,
	SpeedrunToggle_MenuUpdate_m6A4D59E3C7DD5306558FB2A9C43745362B50ED4B,
	SpeedrunToggle__ctor_m882D88FF5D848401A57F51C4A057309563C59435,
	PauseMenu_get_menuObjects_mC12ACC7B71C930CF29812288373FD01490113D48,
	PauseMenu_Start_m4DE86B520C58E4A1F4C1E44C229DF6A66D3C7615,
	PauseMenu_ResetMethodArray_m7ADB3E968655B9526C7850CF9AC62F606079BF20,
	PauseMenu_Update_m66A1E2D2A45F922DFF88D7DAD26E1833593EAECD,
	PauseMenu_FlipFlop_m6BDA6FF7B0650726FA85135B98DBE63E891EF75F,
	PauseMenu_UpdatePause_m8AC33F9A757E21AA7812D1FE32ADA472335ACE88,
	PauseMenu_ActivatePause_m62631E7D27FFBA73CBF69C4A8C8C654089C001BA,
	PauseMenu_DeactivatePause_mFE201F1C0057823F14C485AF38BF1AD6C849611E,
	PauseMenu_UpdateMenu_m3B93426326F6186D271DE794D66D7677A33AB88B,
	PauseMenu_FigureOutSelectedOption_m4DC5E9B44E9D27BEA900131E64B4A188F94DB311,
	PauseMenu_ShowSelected_mD49A1F15FE8BB05884324EF557B638D1A281CE75,
	PauseMenu_HandleSelect_mC301FBBCB1E5AA413FA33010DB82E42B3492D6AA,
	PauseMenu_GetIndexOfMethod_m2FB9AE458B66FEDB0A87F0978459E2490180E279,
	PauseMenu__ctor_m160C6A78E24C65136139628D4BC77D89D26EC373,
	NULL,
	PauseMenuMethod_MenuUpdate_m8F3079902D68739066DC1D0100E21E82DD84AE62,
	PauseMenuMethod__ctor_mF65068BAB2063030419904BD7113202304103B1D,
	RoomSystem_Start_m210B4BE4D67163EAFCCB2DE797A8AB644A5C4799,
	RoomSystem_OnDrawGizmosSelected_mA8D6170EBC4E4A6597BFC81884CC979AA0F1E803,
	RoomSystem_UpdateCameraSize_mAE007A94A8360470F72F343643BA2FCB85037BDB,
	RoomSystem_Update_m122BAEFBDF3324BA0663BBC8D85A3A5C2357795D,
	RoomSystem_ChoccyMilkMakePainGoAway_mF0AAA2BC7084DDC37D23D3876D597EA40FA04612,
	RoomSystem_CheckRoomChange_m353C3041E9FF60F13766FF26B772B2E97A05397E,
	RoomSystem_GetRoomPos_m77A542D6EA38CCD3BCA5AB60779B31F2042C3480,
	RoomSystem_GetRoomSize_mA046E63DC6AEE7F456E6F4E019CE23C8DE281280,
	RoomSystem_GetSpawnPoint_mC306D993617E71105FB40A469A265A4311435A35,
	RoomSystem_InsideRoom_m5EE537DE34D8481F0C29CF8FBDD0021E912469FF,
	RoomSystem_InsideRoom_m5CDD84CB902BE340AC6BBC017DBB09D8CC135A16,
	RoomSystem_LoadRoom_m7F846900CBD98147DEC6F1F80614812394343BBC,
	RoomSystem_RecheckSpawn_mF113974EB2FDE0EC7B54A26BF38A475A0D333AC7,
	RoomSystem_CalculatePosInRoom_m5B749C6E154525E86A7C217B33B8202F2D27B852,
	RoomSystem_FreezeTime_m3FFBFDD448E56E08249184DA59D220473CEC9E21,
	RoomSystem_OnDrawGizmos_mBBBC542085C787B2F18744FCBCFDD701D4DC46D3,
	RoomSystem__ctor_mE32E2689C4BC191E23575C53F63D8D19924CFDD7,
	Room__ctor_mEA60D98B399503A3A290AD7A45218ABAA0B62723,
	HandleSpeedrunTimer_get_displayTimer_m17F5AF6A0394031B96B9CCD51629CA7AE316FBFF,
	HandleSpeedrunTimer_set_displayTimer_m9D1275434F475E6F4657B5CC21EC9391EEE2C9F9,
	HandleSpeedrunTimer_set_timerTime_m1DA1CAE2421478AADFE7BDBE59027BD154C056C1,
	HandleSpeedrunTimer_get_timerTime_mA03EED55589DCD115124E912F7CB2C56C2DD4B89,
	HandleSpeedrunTimer_Awake_m39B2B5F412537FAC509CD36455CBB18E448E89C8,
	HandleSpeedrunTimer_Update_m6DD8847A20B87B274614636AFC0797D3B8495EC5,
	HandleSpeedrunTimer_FloatAsTime_m2FDC202DDB711705BE4369687F60374B138735C6,
	HandleSpeedrunTimer__ctor_mFDBC8417B9F4C18955F5228A3F849D4888C58BD0,
	Chapter1Cutscene_BeginCutScene_mB87A267DFE119B7D85F113CFDD8E562B52B8DB7F,
	Chapter1Cutscene_EndCutScene_mA7F5773F8C932F64A54C268AD443E8A148368FC2,
	Chapter1Cutscene__ctor_m0DDCB54A90A4851683FF8D50D662E688E09B5B84,
	Chapter1Intro_Awake_m8FD093BC0CD13B1A381577E90AF949E99526BB32,
	Chapter1Intro_Update_m39E3E811966F40FECDCED22B62CB08A93F2989B4,
	Chapter1Intro_AAAAAAAA_mEF498C850AE0F647E98CD2893273DD1465F68C08,
	Chapter1Intro_DestroyTheThing_m2BC7D4F3A241A208B57ED15454412B6EE1745D74,
	Chapter1Intro__ctor_m021939BBE9ACDF5A09F3E4D2BAF60395C88E1C93,
	NoiseColor_Start_m5214161A77E15416A29FAADFE9674CE6D5E4CAE5,
	NoiseColor_Update_m22EF5CB1CF5C36924AB61D1C687C11582FC8B6C3,
	NoiseColor_FunnyEffect_m63992ED64687CCCDB8572AA8346480A565C61579,
	NoiseColor_ApplyColorTransform_m71BFB6281D4DE64C03B3167F590C98742C416B3E,
	NoiseColor__ctor_m322A15548EBD28EB7994609630B3E02F5E47CD7E,
	Collectables_get_curData_m989355BEF6AD9EFFEA02A9C48067F646881618A1,
	Collectables_InitializeCollectableData_m008FEBB94A5567F050FCFBEEBC081D8483C0E9BA,
	Collectables_CollectedMarble_m35DB467102E081C98E6C08A27C8B4B8A3A10AEC3,
	Collectables_SaveCollectables_m46A5324A7C9A0CF7299B949C41BADEC8EC3D536E,
	Collectables_LoadCollectables_mB54CDA291E66018CEB183F6CB58B53F769006695,
	Collectables_Total_m8EC36A225CF7C6AE9485B36ED9001019AE58FB1F,
	Collectables_MaxPossible_m9BFEA16A274A13E06A1D13C136099896DB683E72,
	Collectables__cctor_mD3AC459524534DE88304580AE1DB47722944F4D1,
	CollectableData__ctor_m3B6B1EAA9C9DA03DF5A17D10E873FBFDF6D604D5,
	MarbleCollectable_Awake_m4322C98116E26C200D12147010E743602E35F8E3,
	MarbleCollectable_WaitForRoomSystem_mD43B61B4C7F073A5AA5EA657F6942FB2E2C97E17,
	MarbleCollectable_KUpdate_m91A53FB9601D392FDD8087F6BED355E8ECC4A222,
	MarbleCollectable_Follow_mA5890AC7DE41EED969F259A8039923B79FF86281,
	MarbleCollectable_add_CallCollection_mBBF47C12A7C8D4EFB5127DB00E5D429B9A455C89,
	MarbleCollectable_remove_CallCollection_mE330BBF907327E0003FCE317AA149792F1808781,
	MarbleCollectable_InvokeCallCollect_m36ABFC34D6B2ECA9CD090B40000E1E8D6F68A602,
	MarbleCollectable_CollectCurrent_mF440FE839D4C07510160122980E9E2617F144560,
	MarbleCollectable_LoadData_m6733A5A8814264E7C011C39FFE7EAB94EB548A74,
	MarbleCollectable_SaveData_m3DE01AE9751AF7105587AE619579018A151F9452,
	MarbleCollectable_InArea_m8C97F9406A01C2114C3921E3CA5850F6243D59CE,
	MarbleCollectable_Collect_m5488109030B247559467E18B199AEFC10F967AE5,
	MarbleCollectable_ParticleSystemActivate_mDDC4C85160EF558D11B367BC193CB110918F8760,
	MarbleCollectable_CheckDelete_mE602DADDFC93893DE1D822D84D256A5F8B5AD2B0,
	MarbleCollectable_OnDrawGizmosSelected_m268F18079FF295DC79078B26AB34ADBFE6988E37,
	MarbleCollectable__ctor_m2E0ECF274902B986089248300441D3DFF5E536C1,
	MarbleCollectable__cctor_m77D6958CE8B2083123388B0A0A007F2BE2EFA297,
	Core_get_numberOfChapters_m9E7ECBD732C447C16D12BC5508259D26107529CC,
	Core_SaveGame_mEE55B36842F812E0EF2B814A82F06BA05AD6E53D,
	Core_LoadGame_mDB13F76371EA79E243A3662565D18C8484598D66,
	Core_DeleteData_m9220A3CAD2BB00C87B62829946AD70EA79F82F0A,
	Core_ContinueGame_m83B79DAFF85F2B47C3468EB99160D1F847E68A5B,
	Core__cctor_m3669FF895D2A35C5DA5E3F0E32B7C505F012006D,
	Progress_get_curFile_m83153598BAA8ECE7C0453B8C8C8443308F74525C,
	Progress_set_curFile_mFD6F938A6618FF32667258F3A6EC873336B6D743,
	Progress_FadeIntoNextChapter_m6C255F321F36A34BD50F089736B9BD3B77AEC761,
	Progress_LoadIntoChapter_m0E77CE9DFA54A735CE15C2EE58581FE916631725,
	Progress_SetPlayerToPosition_m63ECDA3D3535C364316C2D05EDF5C539CF3B96BC,
	Progress_UpdateProgress_m46F12E7B12ADFE34E04ADC4B2136AABEC48020FB,
	Progress_SavePlayerProgress_m9609F0F1558779308DFF65A71FA44A0D77D89A2A,
	Progress_LoadPlayerProgress_m4DC27533395C099F778472C74D2C306078E3E47F,
	Progress__cctor_m4B4CA8CA3355F80435F6E2733BCEF4E4F2790022,
	ProgressData__ctor_m953F5DC1E5F55E74F23E1BE58189BEA080AFE826,
	DisplayFile_Start_mA70503AE39AB94F3C1F3245AEDB52D489642D2DB,
	DisplayFile_Update_m5090A6E8AD6B0ADDFFB767FD04BAC710E1F06149,
	DisplayFile__ctor_m6E800B95186C9A6F4AF546799D579CA8FA73F04E,
	End_Awake_mD9547194F4FFC0162518B16BB06F97BDC47E61D2,
	End_OnTriggerEnter2D_m526D1F2CD041D3AE529D54FA22AAF1E2ADE734D1,
	End__ctor_m7507A3404C1C1C5401FFB8303216E5ABA4263169,
	EndCutscene_BeginCutScene_m17F83A2F7153FF636162C0B4944567290040F1B7,
	EndCutscene_EndCutScene_mCB4E23A29CF43C5630AB869973FF622AEA153952,
	EndCutscene__ctor_m1BE1D1A9B95F1CDC9BE34E40549F26F354ABD318,
	EndCutscene_U3CBeginCutSceneU3Eg__WaitTilTheEndU7C0_0_m62847328BAA3D4C94584AF25F10F2807A1A458A3,
	BasicColliderBegin_OnTriggerEnter2D_m3E04F4064800A7D046940FFDD806E43DF63D66BF,
	BasicColliderBegin__ctor_m46E06EE964E9DF53545F0FE18705D6D8952496F8,
	DialogueLoader_Start_mCC9AD077F73FC6AF99A74086ABC9E89177384462,
	DialogueLoader_Update_m40A8A98231F951AF1B917A96CD1BD2713E4F92CB,
	DialogueLoader__ctor_m02642214B880AF2B01D61320A83EEF7DE88CD3D4,
	KInput_get_lockControls_m56363EE2260D8EEB7BCADE3124F6EF587620A9CF,
	KInput_set_lockControls_m47F1E7D3F2E4C5559FC57D5D3AB398CD41E09162,
	KInput_get_lockMovement_mD3944C1AFBEBC90ED569382DA1C4EB2DA97EA900,
	KInput_set_lockMovement_mC831D884421400C0682D20B9C2574E7D37B3A3F7,
	KInput_get_lockDialogueControls_m4A368FD6120AA9259FDA2E31EDFFC44F845D3098,
	KInput_set_lockDialogueControls_m8C801CF6C7247A0B50E0A2BD4E141AA9A81AFA9D,
	KInput_DialogueInput_m823C7A75B838BE602E462174D904FEF7DF642284,
	KInput_Horizontal_mF14838BE8DACC225FE2EB198B51E8A975AAF7EDE,
	KInput_FlatHorizontal_m7F90E1C479465E6DFF8DBAB1842CADCCA3D66A07,
	KInput_Vertical_m5A728A02C318C388BF1852846C5299E373223899,
	KInput_FlatVertical_mEE90C4125A1CF491D28FCC03C05E69E359ABD756,
	KInput_JumpInputDown_m614BFC6F510AD364A97F2B0897820BD5EEED7F95,
	KInput_JumpInput_mE29A0CFF30962C399247D2FBF584FFA65A0AE385,
	KInput_WieldInput_mFCEBDE4E727938B3A9273DB487AE8E32905FFEE7,
	KInput_WieldInputDown_m810D242FA840503620FA4787AE7614634E6A0E79,
	KInput_BurstInput_m3496F87BA4449350A440DFE99F201E3DD87B5DA5,
	KInput_PauseInput_mD7D41697F56F021C77E697600BF64DEBA416791A,
	KInput_VerticalMenu_mA3742A0B16FA3A7D19674084D928A6A15CE42CD1,
	KInput_HorizontalMenu_mE9194864FC9BA17D90E988678089DABD965B11D0,
	KInput_MenuSelect_mAC303F98AC161B96548ECF6A5CFEF9D0BD2C1A9B,
	KInput__cctor_m039B1AA347FB071B042E2747F91B552F19E08EEB,
	SoundEngine_Start_mAA676425126C5951949258FD88B3654965C0E470,
	SoundEngine_Update_m589B45D10103D7B78F11800E551ED6C1795CD744,
	SoundEngine__ctor_m2BD5204C94BD004FFCAF17F073377B5BF907DF15,
	SoundEngine__cctor_m22359431FDE6457552A6FFAA1D98CC22749F7695,
	CloudTree_Start_mD5F636CA2C8D21B7D61822C72123D9AB316C2FEB,
	CloudTree_Update_m06539B428DFCC9430FAE9A939546FE3F71A887DE,
	CloudTree_AddVelocity_m477263ED04DD1F8C70140924DF5500407A88CE88,
	CloudTree_WaitABit_mB34404F80270A843B563869DD2377F5FE093DC41,
	CloudTree_Effect_m29ED7C9375D72085D7A558175C66EB15C1B927DE,
	CloudTree_OnDrawGizmosSelected_m99D8EBD5CD5E48F8C2FC80B9875D3C7DADD07BD5,
	CloudTree__ctor_m302E17CEBBF23EFAFCE02F3DCE5AEDF42A44434B,
	LeafPiece_Awake_m8ADB1B193664705EA022B2478DDD3FB4FE0396C3,
	LeafPiece_CheckRoom_mB38E4C67CBD52D407F98FDD7E0C360051C6DDBFE,
	LeafPiece_Activate_m2CA8E03DB437180C7ECFE2B88FC3C10CE0D0CBC8,
	LeafPiece_KUpdate_m6A1A68FC5E48318CB90B61675081F47E5E536F70,
	LeafPiece_KLateUpdateImageEffect_mB9FE052922B3BF404F105B003500D0F9C481F0CA,
	LeafPiece_LoadData_mADC0B38DE793C69D8ED48BDF0D2DD5C89FC8AF0F,
	LeafPiece__ctor_mFC6D9674DC70E138542D0BABB79965B49A43E762,
	Scrunge_Start_m36CFB6E56A22AB24DEA6D7406F8680085DF09205,
	Scrunge_KUpdate_m4EA2D40A76023C7742140B71C080EE096096815F,
	Scrunge_BounceUpdate_m4C60E8B72532A097320BC1E4EFEDFDE1A19532CA,
	Scrunge_AddVelocity_m90EB05816B159A4974B0E1ABD349692FAB1871B0,
	Scrunge_LoadData_m974E1DA18BAED784BD6A98B0D7B4A7957CC4EAC6,
	Scrunge_SaveData_mB2D041CADC5CDCF5ED9FE703F68108FAA621AC39,
	Scrunge_Activate_m69682DF0ECCAB5986D3FF49AD3BB68F7423CA344,
	Scrunge_StartGoin_mF28F59B7F178BB8E07E6866962FF2A396521E04E,
	Scrunge_StopGoin_mCD0B705770B5D6AEC19275FF651FFB9CAFA53D19,
	Scrunge_HandleMovement_m412BB780432A7C04ED2CFB8D687BA74997873E4B,
	Scrunge_UseVelocity_m9029A831A7B417F61A2CF9D482CA0E4636CDEA93,
	Scrunge_CheckGrounded_m6521A5DD976C7EF26F15EC2E637AD06EEE783C7E,
	Scrunge_Gravity_m0886A67463E6B809FB8069C448FDC3990E2FF53E,
	Scrunge_HandleWallCollisions_mA34327F3B5E452043492272E3F9D4CF7D3844B84,
	Scrunge_CheckCollisionSide_m2C1F14FCAB99CD206E5029E56F584EA2C0F289A5,
	Scrunge_OnDrawGizmos_mC3AFBFBD7F054F76ED28AA2AFADD5A8B31E0A7F5,
	Scrunge__ctor_m2810C0C27E0C2C1022A98D021A3C26230597BDF7,
	PartBase_Start_m2B577505F42FF308995D2BE32F6ED24C0973C71A,
	PartBase_TryActivate_m132A6A8435DB03EE665428A50C081FED1D711FC6,
	NULL,
	PartBase__ctor_mE84EAAD997E39F071B68D3FE87DFB9ECA836F600,
	PlatformCollider_Start_mF7977F6F2871EBBC1DD0A6C887BA46CB65FAA6E8,
	PlatformCollider_Update_mC946794E09C6C1EA2286B8005CED83F4AEFAA008,
	PlatformCollider__ctor_m11105413D5B56D6A485E67F2B3E4BCF43637C3B7,
	Conjunctor_Start_m23B713A1A9FAE3BE3E7081D65EBCFCE9B4273E26,
	Conjunctor_Awake_m4DFC723B5B089486C95BB6A7F55E667A518BEB2C,
	Conjunctor_WaitForSpriteRenderer_m7A157D81E1118959E250EC0BB60BA12A61F76E51,
	Conjunctor_KUpdate_m16CB34F37684090AD4849E75FB7DEC7FB231AE07,
	Conjunctor__ctor_m23DD5027E85EE2C263EE8EBD2AFC76E8B2EFE7D2,
	EnergyBurstVisual_Start_mD40BE942A40EAFE72CFD97FD8519E7560B0DE2B2,
	EnergyBurstVisual_Update_m1DE2C8F7132CA35E2C59119525DA716FEFFB5BB4,
	EnergyBurstVisual__ctor_mA3F0DDCB3878AAD4E6B161961312D919EF272C45,
	HandleAnimation_Start_m4508FCFE6E0FC079D22AB09A0F49DBC28A2929D8,
	HandleAnimation_Update_m08353A5E52E52FCA7A2D20367258AC22C147117B,
	HandleAnimation_LateUpdate_mCE2952922513D6149125A63887D10096161A58CD,
	HandleAnimation__ctor_m1AC6A137D0811A09D29E94631D269C4EE7EC1364,
	DestroyParticleOnEnd_Start_mB72FD71BF0B79F34DCCE7289CDA57DA5C8AA85B0,
	DestroyParticleOnEnd_Update_m2A72A53B49DA2F2710C04D217698D8F886D37F25,
	DestroyParticleOnEnd__ctor_m745B4493C8E6AD1753BC3AA40B9F6B5833B5D553,
	ParticleHandler_Start_m74D89BFB259137323493C15703175832BCC09027,
	ParticleHandler_Update_m3E3452A46F8135792E57B01682FE33C6FA21CF54,
	ParticleHandler_SpawnParticleSystem_m71E8ED2BE7FA7778DD67EDD77C40A2430610F67A,
	ParticleHandler_HandleWallSliding_m3ADABE0FE0864EA2DB704BD7264AC4B004A8A244,
	ParticleHandler__ctor_mDA0C1D3873A4184C6FFE06C3B00747AFDFCA047F,
	PlayerControl_add_hitGround_mB87F9CE81272CB4AC4BD6ADAD11CD23E3DF6F0A3,
	PlayerControl_remove_hitGround_m5FEED0DB47A7E7653018D3A3153CD5C9F5295FD7,
	PlayerControl_add_jumped_mC6B4CE145E13B43F8D4C4E9C816ADDEAECAA92B5,
	PlayerControl_remove_jumped_m4EE047959F383AE54845AF791A955DF328F56293,
	PlayerControl_Start_m9E68769B521728F3CA952D11BA9AE068461048BF,
	PlayerControl_Update_mB6BCD0B5C42037B3D8791A472BF6290B1937A58D,
	PlayerControl_PlayerUpdate_m95E6B35AAC3FA8CC136807714548191E2BC0395F,
	PlayerControl_HandleMovement_m087C2E4F647DED88AA73E76589CB3FE503620B86,
	PlayerControl_ApplyAcceleration_m8D538A2F7B545F8A7E3ABE73661A500B2BF8EB4C,
	PlayerControl_ApplyDeceleration_m0AFD62873F2E3D0BA2815F22D04DDC78A73AB976,
	PlayerControl_HandleWallCollisions_m6E32ED141B93FD9208164C961B90AFB346CC8DD6,
	PlayerControl_CheckCollisionSide_m962CAFB5233C69A1584F03D4DF19F21926855001,
	PlayerControl_CheckGrounded_m19288AF245DFF62BA44D0CE23C29967F2D35AE30,
	PlayerControl_GetGroundedTag_mCCF8A5B59E61D35D51136345BF931D7C075E527B,
	PlayerControl_Gravity_m46058E2ED16510B2C4501A879E72EE5EBB1EFA78,
	PlayerControl_HandleJump_m172F3717C4E3A16DB03F4B338D76195886D50D90,
	PlayerControl_Jump_m9A657B9CC98D53BD12AC60BCFA9C59EF5F852EE4,
	PlayerControl_WallJump_m80C0249B83305723EB949EDC9D6E46ECCC1DA971,
	PlayerControl_HandleBonk_m42B24D9659FE83849B7E85F238979D7B6D692348,
	PlayerControl_OnDrawGizmos_mD4CCFC29DD8EE6BEA6F8C867A08916F264FE7932,
	PlayerControl__ctor_mFB09FAB1E5EE3D8037BC0D0DF9294BB501A5C869,
	ReturnByDeath_Start_mD6518959257C98B68F052FFAA021AB0E05AE69CC,
	ReturnByDeath_OnApplicationQuit_m52CA4D692F53B0C7FAD9E2437D627D56DCA29267,
	ReturnByDeath_OnTriggerEnter2D_mF5F7AB2AA79660D30E426222E9807100C7D22DF3,
	ReturnByDeath_Death_mE09DFE330B861C8947CE85E9CC79C831E305A85F,
	ReturnByDeath_WaitForDeathToEnd_m2D588917796C1033B728EA18D7497CF530C24D64,
	ReturnByDeath_IFICOULDCHANGEMYTEARSINTOSTRENGTHANDPOWERMAYBEICOULDREACHTHEFUTUREISEEINMYMIND_BRING_IT_TO_LIFEE_mFED9DD2699FDF4D7A419C89BE3B484EC977ED52D,
	ReturnByDeath_ReloadPlayer_mB08799AB787CB0447421090DF76E9317F6EBF459,
	ReturnByDeath__ctor_m7DD839BB219D264A30E420A8636783F92B795A4B,
	ReturnByDeath__cctor_m29C1AE02A454E43AACB4A5CD3BE60E8DEE2836B4,
	PlayerSound_Start_mC3A6B7493D417266D29C0703AA2A0813145D8380,
	PlayerSound_Update_mAB715EB4017653264E213B3AB8F1B13A371E465D,
	PlayerSound_JumpNoise_m2BAAEAEDA36C4D07F5ADC0AA606F06D4F884FFEB,
	PlayerSound_StepNoise_m0C74831594F98329DA23826B02F259E843D2C3CE,
	PlayerSound_GetCurrentAudioClip_mC2DEFF22C83839CEEB203E81DBBEEA90F7B62D48,
	PlayerSound__ctor_m1F6B8AEDBD15A16C01E9E9BD119739C6467665BE,
	Wielder_add_wieldActivation_mB8091E276A83C6429D0BDE841E049E2A9EA054FB,
	Wielder_remove_wieldActivation_m2BE9DC75622459679EF08FE17C7EA64F8FBF2A46,
	Wielder_Start_m187C6AB7DA88AEDD3F07B599AEECE056B7DCB32C,
	Wielder_ClearEvent_m853576415D47FE5ACC9B80A6D44B6DE03A7939BF,
	Wielder_WieldUpdate_mE32DE60EB4E9433913C71EE846A164B737AFA369,
	Wielder_LateUpdate_m0DEA4B56C8F54A18FE5241627BDAD5B5B2B5AF9B,
	Wielder_EnergyBurst_m7F00DE389A3539D5A3D569316B65AC7EC4F2AF46,
	Wielder_Blink_mAD425DD75F24916FA097A28E58C114CA71754E8A,
	Wielder_VelocityShift_m545F881D1FF689976D92CF57B5FBF2BF04442A85,
	Wielder_VelocityControl_m00D2DC47C46C610658EB642B97344CCF5E65FC4B,
	Wielder__ctor_mBB3D81A42693654DD537906E90D6A3971EF733ED,
	Chapter0CutScene_BeginCutScene_mCF0A051D2CFB9F677845FFB5CCA62E78F689DC9D,
	Chapter0CutScene_EndCutScene_m8B641EFE6FF6EB46330724FF31C2913A7A643387,
	Chapter0CutScene_MovePlayer_mB20CE757487E0DF83AA41EAF88C57536F7B3FD6A,
	Chapter0CutScene__ctor_m2A75CD6B0A15B01A7A73092A004442EFE91A402D,
	WakeUpDialogue_OnTriggerEnter2D_mBE9882C63A8C938366C549C906EF48D1FD124B19,
	WakeUpDialogue__ctor_m337A44C5B6AD5FF19139B284E025E933CE26A939,
	Chapter1Collider_Start_m5C310C6CB63DFB535DFD018328AED25C1F18796E,
	Chapter1Collider_Update_mE7C97B997585E270E613C794CB621DE6E42A3FDB,
	Chapter1Collider__ctor_m469BAB018A07D3C736BB4B595E6913D15547CEB7,
	CutSceneChapter1End_BeginCutScene_m0DADC648233997AA4C9BCCCFC5DCB074CD15F4BB,
	CutSceneChapter1End_EndCutScene_m5702B5757BC55CB9EB786529CDF51133493BFB35,
	CutSceneChapter1End__ctor_m27C379E0957CE35113DD12893C0D7638A15A521D,
	GoNextChapter_OnTriggerEnter2D_m9621735E48F2AA06DEA3AB607BEFE76825310F20,
	GoNextChapter_Thing_mAA9DA5380A844F53B4FC45DC7DF494984F0D3823,
	GoNextChapter__ctor_m10A30A5F5CE2DDC66211B5274BB6A47EF356E9F6,
	GoNextChapter_U3CThingU3Eg__waitForFadeU7C2_0_mAB35DE4A29323D2586899ACC98FF29D792B60FA5,
	RunChapter1End_Start_m4CEFAAEAB5D7615B2C9BA8A87E5A31D8B23D2A1C,
	RunChapter1End_OnTriggerEnter2D_m5C078563E6FBDE57208CCAA7395E1311E03D7D27,
	RunChapter1End__ctor_m8CE1E759A7FA4E0823EB02D08FFF57DEE586C826,
	SiblingRuleTile_RuleMatch_mA548BA6DC40A64FBF82BA773FEDA5104F3E4C256,
	SiblingRuleTile__ctor_m86B52B459F7636693438DF610B110641F71A41FB,
	SpriteModifier_ConvertSpriteToNewTex2D_mD81D4845BB2F1332179885DA47B02EE372536CF1,
	SpriteModifier_ConvertTexture2DToSprite_mB358E63284C4928D1153A49348F44B17785FAF76,
	SpriteModifier_GetPivotInWorld_mD3DB7CE75C1B01DC26A9BD6693141D53ED031B0A,
	SpriteModifier_ReplaceColor_m19D6B06DDBF60AFE58A44735F1C8E0F0F9654FD4,
	SpriteModifier_TintColor_m703301CC6274D798C69C4BC8A5525F5FBAE572D6,
	SpriteModifier_Interp_mD826021B3B9258DC8E5113FA540242ACBB823441,
	SpriteModifier_GrayScale_m3C896045E5E2DEAAE8A7FFF64424C43B7F8CEC7E,
	WinScreen_Start_mDFE8D3BF639D488F892A129704B0E9C507197D06,
	WinScreen_UpdateRecord_m8067D786ED54883320FB81F6D30049FF6B9C0080,
	WinScreen_UpdateCollectables_m96ABEABF2F51BD175C837B57E819B580DEDF593F,
	WinScreen_Update_m1C20AA53074CCC3BF1DD9CB95A2925F5F0B43A1E,
	WinScreen__ctor_m74A324860E652FFA4A26DD8E21810F4B79EC906F,
	WinScreen_U3CUpdateRecordU3Eg__DeclareNewRecordU7C6_0_mD252D6B98328199D13BD1F98EE4B25E48910062F,
	DialogueAnimator_Start_m8F172C6AACC682D5AF328C061C2931A79707803B,
	DialogueAnimator_PlaySelf_mC4EC45A1457FE44EF1CCDB37C067B5AE0241474E,
	DialogueAnimator_ForceEnd_m3671F6AA9928BC6D4F23D58283DC5AA911066E03,
	DialogueAnimator__ctor_m5631C331A743E244AF2722291C895C375508A26B,
	DialogueBox_Start_m190C0010BD7C5C98C55B21E1E034083E06E18BDF,
	DialogueBox_OnDestroy_mE8D89300842D3FC144FC03C7646117ACD126F05E,
	DialogueBox_UpdateVisibility_m6CAFEEC5308671D4BAECF44FEE77B41EC99F0ED2,
	DialogueBox_UpdatePosition_m6A9BED8FB3D23EF75AF3B0EF6A73548F9755648A,
	DialogueBox_SetVisible_m04BDCD11ACCF598BCD9D93051E6BC1C0A422C979,
	DialogueBox_UpdateName_m224BEDDF6C8AC581D7DEFD4F6A4A352ECB5EB10D,
	DialogueBox_UpdateFace_m998DDF2D0AE24FE1752FAB7AA747018B4E76B18B,
	DialogueBox__ctor_m47113684FCF3186E4E5CD0F442349DE0B31ADE2D,
	DialogueBox__cctor_m1A67F9D91018A8659E24B2441766D19C491538C7,
	DialogueListener_Start_mA3E945EE3E457783AC5FE22061D073F41840529A,
	DialogueListener_OnDestroy_m12DFF0AB80F30B8AF0498D1503FF80DAEDC9C9AA,
	DialogueListener_End_mEC950A0A3D67366D3569D320B4272EF45074B8CA,
	DialogueListener_DialogueTimer_m44B953F980F20DDE000708DB1528D86236706AD8,
	DialogueListener_Activate_m6DA479C7C6F09971ECBCA7ACCD865EA63969A22C,
	DialogueListener_Activate_m2CA424B0E109AC2FF2CBDF7E1EEE9E37F9E120C3,
	DialogueListener_SetAnimators_m74E39D35577DF4B2AF00F6985DD7FF79FB89FB52,
	DialogueListener__ctor_m2831654C736BAC57C0BA9BB3DFCB3B230D166239,
	DialogueListener__cctor_m1BB7B4AF015008757DBA89BE93B82DA2392FF72D,
	DialogueSounds_Awake_mB596BC3D70DB758A0AFE3B989A4E7D74B8D7AD4D,
	DialogueSounds_PlaySound_mAA09A52B5F291B53E0B902563E7142169DD5CBDA,
	DialogueSounds__ctor_mEE7DDF36445038802FFDDAD1316720C80186363F,
	DialogueText_Start_m5C5BB91B52EDE9A42A3A6CC36D9A0417712E357B,
	DialogueText_UpdateSelf_m51D9F8C8A988852AE82CCC04F15F935953F218C8,
	DialogueText_OnDisable_m1AA74743FC36B13041EA49AF726BA345AD8EAC36,
	DialogueText__ctor_m28F202BDBC2FB8BE413C3C1C66DF7C6C11C7F8F2,
	DialogueSystem_get_cur_m1FCF94C0E12775245145A8889B0D602CC2EA7B67,
	DialogueSystem_get_pack_m2D4F02FACD3DA250DFD1A651EEE7B5760A5A9BF9,
	DialogueSystem_get_isRunning_mCA448E584DBB4353EB16AAB9D0FAF27F6A0DC8E5,
	DialogueSystem_add_DialogueCall_m37B1A799ED23EEC1E07BADEE81EE8737AF9E229D,
	DialogueSystem_remove_DialogueCall_m8A6BC9342196795994F97B6AE77AB3B5A8EBF888,
	DialogueSystem_add_SoundCall_m44A8406BCC313BAE3358C7E75C3177CB1089DF56,
	DialogueSystem_remove_SoundCall_mB0863FF3F8F694AC5FB999B0157C327FAF8D7A0A,
	DialogueSystem_add_AnimatorCall_m996BFC400FEE54D5D9DC3936A22CA2CD4A71EFCD,
	DialogueSystem_remove_AnimatorCall_m5B19AC05886C15273171ED10677F2F09663B302F,
	DialogueSystem_add_AnimatorStopCall_mC8B2D60C2B00B0134050800472A308BDDF0D5AA8,
	DialogueSystem_remove_AnimatorStopCall_mE50C1D235DF1976D48534F6D0F36BAC454AAA596,
	DialogueSystem_add_BeganPackage_m622934E35755F42DBB4C478162B7576C7212C72B,
	DialogueSystem_remove_BeganPackage_m6D9CCD3B19EF78C7CDC41E6E8496C1F906002E2F,
	DialogueSystem_add_EndedPackage_mCD084592A6B93DC1DB852BCAD5961DD52FB4F491,
	DialogueSystem_remove_EndedPackage_m12765F60697035B5D421587DE5F7671F1A077A9F,
	DialogueSystem_BeginDialogue_m321A820A1BB466BA900CEC9B6A0BE6CE67AC564B,
	DialogueSystem_BeginDialogue_mF30024C22379F201960D3E0678048C9FEB30C4AA,
	DialogueSystem_SelectScene_m995E6D6E31A45627E41E061A6A8FFA809E02DCB8,
	DialogueSystem_SelectScene_m3334404F320CD1CC783B39D4B27FC1CD57265754,
	DialogueSystem_AdvanceDialogue_m3EAFCE87353892AC3199F9B4199F39D95884DF2C,
	DialogueSystem_ForceEndDialogue_mF56B7DD1E46CDC36E38D7CB93C7E42D1B941B13B,
	DialogueSystem_Sound_m0B2C36CA4A59CBF7296DA03FA2A0EAC8327ED7F7,
	DialogueSystem_AnimateCurrent_m81D5DDE7E7F1A1DBBCB3435E86D793EFC5156D12,
	DialogueSystem_EndAnimations_mC5C92D27E6C499F2FBD021606DE8F28CCC3E975A,
	DialogueSystem_AdvancePackage_m0129F112AF1978E3076EBD8BCC3857AA0C4C58F0,
	DialogueSystem_EndCurrent_m840482D6DAE022060B925194B1DF500DCE86603E,
	DialogueSystem_Begin_m087D743F902C6987CCFC0FB51648BB8D229734E7,
	DialogueSystem_End_mFD428BBA15F6F87B09C88CAB0F28D97EDE06684A,
	DialogueSystem_Save_mA794CB256547BA8E376898EA4DBD971552F1C6FF,
	DialogueSystem_Load_m1E09E04E39904DC450BB0DCA589100053F973438,
	DialogueSystem__cctor_m16FAD7DF6490DE12D8239DDD98DA81977EE0C13A,
	DialogueScene__ctor_mE73977AE531F8923C3893CE05A7899A5D651A338,
	DialoguePackage__ctor_mAF58F1F68828DCEDBA2BC11A6493AD4293D036DF,
	DialogueAnimation__ctor_mBA600C2860EA7EC662C06932725D1B2C345CC79E,
	DialogueLine__ctor_mB386FE7E0F3B0F65052AF4EE009AD50396445029,
	CharacterAnimator_get_cur_m12CA24AA25328F3704D753C5EFE45FF7DB3A11F3,
	CharacterAnimator_get_anim_mC6BE709BCED9B65E6331E1A5793CF620C805B0D8,
	CharacterAnimator_get_curFrame_mC0511596444F5F5BEBB1B82EEBEED9FA09E1D1CC,
	CharacterAnimator_Start_m31DD092D8255D5B5A82B9635DD77CB60B18B98E1,
	CharacterAnimator_SignOn_m0AD9ECE0C5B8AEF37A3B23E16282A8BF3A4FD26C,
	CharacterAnimator_SignOff_m5E532782C5FDC2A48B29CC265B907FE28120BDDD,
	CharacterAnimator_Update_m18E88FBBC03D510434FDC4FDCC798463B1B00DB1,
	CharacterAnimator_OnEnable_m49F25DA12A666922C3DF50FFE46E26CB40B60F13,
	CharacterAnimator_OnDestroy_m5BF728F7F0F6D7405C034244ED1AEB5954E1895F,
	CharacterAnimator__ctor_m1ED19457E2F75BE8EC72C5335985CC8661903E24,
	CharacterListLoader_Start_m3A943AE87B7EAC777284826D7FFCE7B8031C6F3F,
	CharacterListLoader_RegularCleaning_mFF8BB3F3CAD3CAF1401D8300DD25C7D9CB89CE58,
	CharacterListLoader__ctor_m0A0BEC21D030433FE30ACB03522837F428209A67,
	CharacterSystem_add_Saving_mA78D70B6FA1205A5473365A0FEF808900ED9639F,
	CharacterSystem_remove_Saving_m43B7C872E6BCF55F2EF83551588974B5AB94D4BD,
	CharacterSystem_RandomBullshitGo_mEBB48C65A9142C3A95DAB4EE5571802A0B39E6BD,
	CharacterSystem_Save_m649CF4B9D7A2259E39D555F9F163DF016798C946,
	CharacterSystem_Load_mEC48128AA3C5C34B62CE69E6B7D9A925E7D241A7,
	CharacterSystem_Exists_m2A9C8F1AC1747E7335C788B51C41D383A139E0A9,
	CharacterSystem_Prepare_mA5364A656E713186D00C5F3DFE49EB8D7B526C04,
	CharacterSystem_LoadInChar_mB684574FB0C29F88A194A75ACB90FA1E382FF32F,
	CharacterSystem_UnLoadChar_m32CA3D1A5B17B2236BFF7BD7FDB8A0047CCEC808,
	CharacterSystem_CheckSignedOn_mAC00DA19DACF24F58CA9B2A6BC11C3E305C52332,
	CharacterSystem_CheckSignedOn_mC1FFC28B89FA41477E42CFD72A1CF7D0D8194DA3,
	CharacterSystem__cctor_mA4162F084CDFC7CE54A9F0464CCED1522B1D137F,
	Character__ctor_mE9DC2D041D5166A615FDF6996C65F27B34F55A64,
	Character_GetByName_m0DC9C8644EE7EEB9DA94B73BC72B19E5CFEFDD2D,
	CharacterAnimation__ctor_m4B3B3A994CE5D1BAE20ADC3FCC4AE97B251F0810,
	CharacterAnimation__ctor_m500E115A287B82898B5D8CAD2D9B2C797300DDB2,
	CharacterAnimation_SaveToReference_m83F76E2E6E3DE6BB17A1B21F75A9345D34D7B21B,
	CharacterAnimation_LoadFromReference_mE493DD6459D7F6E5A6D97CD7F9454A898EB462A3,
	CharacterAnimation_RemoveUntilResources_m3358F09EEF5CEA51562E98D2F65FE5235E9AA300,
	SpriteReferences__ctor_mD204383C8F38153FD60B335292C7B27AD24FC90E,
	U3CMoveToU3Ed__11__ctor_m28B22E6C0A568D7533208F59139E9C45FEFA311C,
	U3CMoveToU3Ed__11_System_IDisposable_Dispose_mCE1E98BCA6EA4A273CF019515D1FD6BD1C8B9487,
	U3CMoveToU3Ed__11_MoveNext_m643C64B9928299FBD1E27BBB4E1A44284F439F00,
	U3CMoveToU3Ed__11_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mEFB3D7120DB826D86464D3D7447BA06D1DC6DA52,
	U3CMoveToU3Ed__11_System_Collections_IEnumerator_Reset_m900236E771105AFCD0838EFF9C945FAA333CF926,
	U3CMoveToU3Ed__11_System_Collections_IEnumerator_get_Current_m9B36F54FFF3F948092A2EC15F90928BA78523F02,
	U3CFreezeTimeU3Ed__25__ctor_mE8D750D103495C0D90552BE10BB42B9818577C24,
	U3CFreezeTimeU3Ed__25_System_IDisposable_Dispose_m1005A4A74AA407FB453DB0A12559ED090290BCE5,
	U3CFreezeTimeU3Ed__25_MoveNext_mF524CB963935C801C450C0A98F55D8AA2A5EC24E,
	U3CFreezeTimeU3Ed__25_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mBA81A6D214ABA0E876A4A1571E59DE8544735291,
	U3CFreezeTimeU3Ed__25_System_Collections_IEnumerator_Reset_mD4F3156E71D7510901D0942FA7ACD294CFE05A29,
	U3CFreezeTimeU3Ed__25_System_Collections_IEnumerator_get_Current_mC9E814CC791A3CAE03CE2432D165E0BAE378EA1E,
	U3CAAAAAAAAU3Ed__5__ctor_m656595BCEEB9A1F00955BE77173C5ECFFBC94A0D,
	U3CAAAAAAAAU3Ed__5_System_IDisposable_Dispose_m69ED5822F7DAEC04D263F496AD8A9070AF5ED4D6,
	U3CAAAAAAAAU3Ed__5_MoveNext_m2CE8CAD00222F1D3B8C7F6141BB482379448C9D4,
	U3CAAAAAAAAU3Ed__5_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m8B36C63B19C40D0219BEC6140633D96B24365495,
	U3CAAAAAAAAU3Ed__5_System_Collections_IEnumerator_Reset_m23CBEEF99AB059B222A76DED4431570284A3E15B,
	U3CAAAAAAAAU3Ed__5_System_Collections_IEnumerator_get_Current_mB96FABC6B0E8CB10457374A905CEBAD03EAB0AF2,
	U3CWaitForRoomSystemU3Ed__17__ctor_m8E4328143EFD4A5C3026717F2AFD3229E926BD4F,
	U3CWaitForRoomSystemU3Ed__17_System_IDisposable_Dispose_mA67C767AC3CF877CFE0EA952FAA457F89B20E03E,
	U3CWaitForRoomSystemU3Ed__17_MoveNext_m95EFA54ED84A113787F0BA7139D2BF8B922C1945,
	U3CWaitForRoomSystemU3Ed__17_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mE0262488EA2C5EA3F5B40D6013C1360C3FE9D82A,
	U3CWaitForRoomSystemU3Ed__17_System_Collections_IEnumerator_Reset_m7BF2BE14C3B8F153BC8049690AAC33CCA91D7B92,
	U3CWaitForRoomSystemU3Ed__17_System_Collections_IEnumerator_get_Current_m2A5E08D591CB96C144B08516FB1044381F00A6B9,
	U3CFollowU3Ed__19__ctor_m7C0E668F5A8F755D49CD9CDDB9FC932E06819748,
	U3CFollowU3Ed__19_System_IDisposable_Dispose_mAE3A090E6530E0641C47139985CB8978A3B9CC58,
	U3CFollowU3Ed__19_MoveNext_mB799E50B40C228527B78AB57AF485646BDC93C8A,
	U3CFollowU3Ed__19_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m9A4270D31C5301CB9BCF04ECC7FC054665DB7722,
	U3CFollowU3Ed__19_System_Collections_IEnumerator_Reset_m6C5C19D171CF83F6AD628BF6153A18946AA8EBE3,
	U3CFollowU3Ed__19_System_Collections_IEnumerator_get_Current_mF634E7AD7826C83C374D564BC44ED70A79F46A31,
	U3CCheckDeleteU3Ed__30__ctor_mB81324F704652F0816682C4BAB6388B016FD1322,
	U3CCheckDeleteU3Ed__30_System_IDisposable_Dispose_mF89E5D423096C655702101DABFDC686D4B64A3D0,
	U3CCheckDeleteU3Ed__30_MoveNext_mD35B95252F24F7349B8660B703B2E4EF2379E5EF,
	U3CCheckDeleteU3Ed__30_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m38D000D772779BC7C745743DE1F426CF156188BD,
	U3CCheckDeleteU3Ed__30_System_Collections_IEnumerator_Reset_m8A7618CFE83ECF44E0476E59F828395FBEBB9FD2,
	U3CCheckDeleteU3Ed__30_System_Collections_IEnumerator_get_Current_mF2BCD757F4BDEF9126FB4EA1FAF15736F6D79118,
	U3CFadeIntoNextChapterU3Ed__10__ctor_m6F02F4D82320D3B9A8EE69B8852B4345EC6B40BD,
	U3CFadeIntoNextChapterU3Ed__10_System_IDisposable_Dispose_m39C3FCE8F5479A67349C0E29ECD60630C70546E3,
	U3CFadeIntoNextChapterU3Ed__10_MoveNext_m5047B7F0C8AFD23439B77EE41733135E04C6D76F,
	U3CFadeIntoNextChapterU3Ed__10_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m8291835935B211B26EB45AC0932E007DF389217F,
	U3CFadeIntoNextChapterU3Ed__10_System_Collections_IEnumerator_Reset_mEB414BB3C423024F9A094EAD26CB7A200B663DCC,
	U3CFadeIntoNextChapterU3Ed__10_System_Collections_IEnumerator_get_Current_mBA68FD81E7E3FE6AC3B111B30EE58D329B5536F0,
	U3CU3Ec__DisplayClass12_0__ctor_m32ADD498CBC86F5B24FF6924A16AE3D711971027,
	U3CU3Ec__DisplayClass12_0_U3CSetPlayerToPositionU3Eb__1_m0ED1FF0D11E54429404B025156FD8F1A7B1ADA01,
	U3CU3Ec__cctor_mC58D280F3E75566442D14F11105BECF7AA561466,
	U3CU3Ec__ctor_m44BD61E15C2487E25DD09E1485AAE9218C022AA5,
	U3CU3Ec_U3CSetPlayerToPositionU3Eb__12_0_m1CC1079B7B758C12A9136320EB86549E74EAE153,
	U3CU3CBeginCutSceneU3Eg__WaitTilTheEndU7C0_0U3Ed__ctor_mAA0C0256BFB9BF1A1D481307E9F41506C160D6EA,
	U3CU3CBeginCutSceneU3Eg__WaitTilTheEndU7C0_0U3Ed_System_IDisposable_Dispose_m70B977CC33A188CF98091DC2F22434937FC94D22,
	U3CU3CBeginCutSceneU3Eg__WaitTilTheEndU7C0_0U3Ed_MoveNext_mDF4F9771070977AD5C5C68B5445151BBA6F4DAF2,
	U3CU3CBeginCutSceneU3Eg__WaitTilTheEndU7C0_0U3Ed_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mE1CE180DA3E4AC0E48789937DA33DDF6D7F09293,
	U3CU3CBeginCutSceneU3Eg__WaitTilTheEndU7C0_0U3Ed_System_Collections_IEnumerator_Reset_m71C20905DFE610DC763C98490328DC3017AD0205,
	U3CU3CBeginCutSceneU3Eg__WaitTilTheEndU7C0_0U3Ed_System_Collections_IEnumerator_get_Current_m1196321B7897D9FDEB6C76F13B08AC8FCC5DA74E,
	U3CWaitABitU3Ed__10__ctor_mC0CABE565DBD54F31655490EDCFD8341BDADA118,
	U3CWaitABitU3Ed__10_System_IDisposable_Dispose_mC875AC1F6FCA0F715CD85503530FF68F63709AD9,
	U3CWaitABitU3Ed__10_MoveNext_mA2693546853832CFD4D71C20EA3D35D716A7B37B,
	U3CWaitABitU3Ed__10_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mD879299E6A0480BA3AA6FB6710D816FE3476348E,
	U3CWaitABitU3Ed__10_System_Collections_IEnumerator_Reset_mA4F6D416D50D490362175E76C1363FB0B1170DE4,
	U3CWaitABitU3Ed__10_System_Collections_IEnumerator_get_Current_m02E2C7E22098830990491312AB257814FAF95177,
	DebugRay__ctor_m71C29A96CE1DB23E71EDD45B72D61D680FC92C2A,
	U3CWaitForSpriteRendererU3Ed__3__ctor_mA64E4D48606C4F45AEC0B14ACB75F928239CFC3C,
	U3CWaitForSpriteRendererU3Ed__3_System_IDisposable_Dispose_mDFB66E4A0DCD8A8537F34AE3644CAA89D695DB79,
	U3CWaitForSpriteRendererU3Ed__3_MoveNext_m424650EB1D8B632A5EB79AE2A7A410DEAF53C3B7,
	U3CWaitForSpriteRendererU3Ed__3_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m7B27ED329C1FF5A2E2F073C1CBA2E91B90F73BDA,
	U3CWaitForSpriteRendererU3Ed__3_System_Collections_IEnumerator_Reset_mF6C9DE3A1E4E0C3F4BBF3D6A7993881F035F02EE,
	U3CWaitForSpriteRendererU3Ed__3_System_Collections_IEnumerator_get_Current_m8B915BC776DE696F82384D531F0F3A1BA04D8B19,
	DebugRay__ctor_mA99D3FE99AD6CF0D4E8751DF340FDCCE421D8BD0,
	U3CWaitForDeathToEndU3Ed__8__ctor_m164D9231AFC44C59DCC209391B730D2282B53447,
	U3CWaitForDeathToEndU3Ed__8_System_IDisposable_Dispose_mBA32A32030200A779B7D7FCAC7E0E993242D25A3,
	U3CWaitForDeathToEndU3Ed__8_MoveNext_m2017755B3B6ED8DAC9A4430B50D5E29379B23596,
	U3CWaitForDeathToEndU3Ed__8_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m9EB154986823BE4A11E2EE578ADA2CDA26291130,
	U3CWaitForDeathToEndU3Ed__8_System_Collections_IEnumerator_Reset_m10549E2EF220D3C67C9398A496E5EDFF9658681E,
	U3CWaitForDeathToEndU3Ed__8_System_Collections_IEnumerator_get_Current_m0C3DABE3A0A2001E4CEC715572B4C1C8A1F494A3,
	U3CVelocityControlU3Ed__24__ctor_mA7D49A9E638E0818A671216C92B9698919E23356,
	U3CVelocityControlU3Ed__24_System_IDisposable_Dispose_m9AD3848000B79F45FB17EF8DCD7C2FCDF30A5B68,
	U3CVelocityControlU3Ed__24_MoveNext_mB5AD235033FFD49B25D72D2CB0657EE991D79E9E,
	U3CVelocityControlU3Ed__24_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m9CEC7E5CB5F7D6512BA931970592442D47E45D8C,
	U3CVelocityControlU3Ed__24_System_Collections_IEnumerator_Reset_m500784131834CEDCA798C55294716756BB23D7E3,
	U3CVelocityControlU3Ed__24_System_Collections_IEnumerator_get_Current_m96555EFE651E349B2FEE95A79292CD8C993FCEBB,
	U3CMovePlayerU3Ed__3__ctor_m5627BE7C5A79C6C16BFC8FCECBBD8E684E8885AC,
	U3CMovePlayerU3Ed__3_System_IDisposable_Dispose_mE5A29E5AE65C44B6200F9EAD20F6D4F53F89E362,
	U3CMovePlayerU3Ed__3_MoveNext_m0F18E5BD91C70C6E0EF1F9606CA6E037F25210E9,
	U3CMovePlayerU3Ed__3_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m96686D17D6569A951A142356B04B68D23611063D,
	U3CMovePlayerU3Ed__3_System_Collections_IEnumerator_Reset_m46EFCD65AE33249935241D8AC9C13B7873D41518,
	U3CMovePlayerU3Ed__3_System_Collections_IEnumerator_get_Current_m80EF404750032AC6AC2498A60C65F94723F3E1FC,
	U3CU3CThingU3Eg__waitForFadeU7C2_0U3Ed__ctor_m985622B5CD38C2860E6F3F188A9D1433B3157675,
	U3CU3CThingU3Eg__waitForFadeU7C2_0U3Ed_System_IDisposable_Dispose_m4A193F633B76B63BDCC81FACEA6216B70A768A17,
	U3CU3CThingU3Eg__waitForFadeU7C2_0U3Ed_MoveNext_m1ED0F153DAEAE79B14B61DF0B6B44F37F84DA406,
	U3CU3CThingU3Eg__waitForFadeU7C2_0U3Ed_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m0C5C5DEE628C1B7FC64FD7E5321433DFA637AC2C,
	U3CU3CThingU3Eg__waitForFadeU7C2_0U3Ed_System_Collections_IEnumerator_Reset_mA797439FB1BCD1B12A57A5E615AEBB90E4CC6681,
	U3CU3CThingU3Eg__waitForFadeU7C2_0U3Ed_System_Collections_IEnumerator_get_Current_mEEC76A4C951B38ACC0B4E1C67DC9BB07848E1B86,
	U3CDialogueTimerU3Ed__8__ctor_mF57CA110C4BA67709F2D23B285C515699AD93DBD,
	U3CDialogueTimerU3Ed__8_System_IDisposable_Dispose_m2F9AF8E0887D0A92373EB07B2F1845CA6F9384C8,
	U3CDialogueTimerU3Ed__8_MoveNext_mD3D8D8F1B5F82CD9FCBD315313AF0F72CAF4D949,
	U3CDialogueTimerU3Ed__8_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m96040DAD6EAF9322D05B4D52D18F74B600B7F236,
	U3CDialogueTimerU3Ed__8_System_Collections_IEnumerator_Reset_mE3A557C7558847B80A8FBAC2006E2AD5C3B3C2E5,
	U3CDialogueTimerU3Ed__8_System_Collections_IEnumerator_get_Current_m5645CE4B56F1F657ED1F46BC8BD3FA96DE5617B7,
	U3CRegularCleaningU3Ed__1__ctor_m80E4158D4E119C2B5C79BE8C8D3177A167805813,
	U3CRegularCleaningU3Ed__1_System_IDisposable_Dispose_mEC933010285B4E31D7A595DB4FC76A3FD0D484DB,
	U3CRegularCleaningU3Ed__1_MoveNext_mE388E4C5C26DCADB4DE3FB467D83E9E3223774F9,
	U3CRegularCleaningU3Ed__1_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m61026EDCB5BC5E3E99A8C238594EE59D26ADAD74,
	U3CRegularCleaningU3Ed__1_System_Collections_IEnumerator_Reset_m2AF6C343C87ABC966BD81241ADF0972A88655092,
	U3CRegularCleaningU3Ed__1_System_Collections_IEnumerator_get_Current_m2A0728739DEBE60A6B26F03B4AF4B354BE92E1CC,
};
static const int32_t s_InvokerIndices[542] = 
{
	23,
	23,
	23,
	49,
	49,
	23,
	3,
	3,
	1737,
	23,
	122,
	3,
	23,
	23,
	23,
	49,
	796,
	114,
	122,
	122,
	122,
	122,
	3,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	3,
	23,
	3,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	14,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	116,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	1903,
	1903,
	2147,
	30,
	2148,
	32,
	23,
	1099,
	14,
	23,
	23,
	2149,
	49,
	796,
	1294,
	1143,
	23,
	23,
	89,
	23,
	23,
	23,
	23,
	23,
	23,
	14,
	23,
	23,
	23,
	23,
	23,
	2150,
	23,
	4,
	3,
	133,
	3,
	3,
	131,
	131,
	3,
	23,
	23,
	14,
	23,
	14,
	122,
	122,
	3,
	23,
	23,
	23,
	1130,
	23,
	23,
	14,
	23,
	23,
	3,
	131,
	3,
	796,
	3,
	3,
	3,
	4,
	122,
	43,
	133,
	3,
	3,
	3,
	3,
	3,
	23,
	23,
	23,
	23,
	23,
	26,
	23,
	23,
	23,
	23,
	14,
	26,
	23,
	23,
	23,
	23,
	49,
	796,
	49,
	796,
	49,
	796,
	49,
	1143,
	131,
	1143,
	131,
	49,
	49,
	49,
	49,
	49,
	49,
	131,
	131,
	49,
	3,
	23,
	23,
	23,
	3,
	23,
	23,
	23,
	14,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	2151,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	14,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	26,
	26,
	26,
	26,
	23,
	23,
	23,
	23,
	290,
	290,
	23,
	2151,
	23,
	14,
	23,
	23,
	23,
	23,
	114,
	23,
	23,
	23,
	23,
	26,
	23,
	14,
	23,
	23,
	23,
	3,
	23,
	23,
	23,
	23,
	14,
	23,
	122,
	122,
	23,
	3,
	23,
	23,
	23,
	23,
	23,
	14,
	23,
	23,
	23,
	14,
	23,
	26,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	26,
	23,
	23,
	14,
	23,
	26,
	23,
	1607,
	23,
	0,
	1960,
	1308,
	2153,
	2154,
	2155,
	2156,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	31,
	23,
	23,
	23,
	3,
	23,
	23,
	23,
	14,
	122,
	133,
	31,
	23,
	3,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	4,
	4,
	49,
	122,
	122,
	122,
	122,
	122,
	122,
	122,
	122,
	122,
	122,
	122,
	122,
	122,
	133,
	122,
	133,
	3,
	3,
	3,
	3,
	3,
	3,
	3,
	3,
	3,
	3,
	3,
	3,
	26,
	27,
	62,
	2157,
	14,
	14,
	14,
	23,
	32,
	32,
	23,
	23,
	23,
	23,
	23,
	14,
	23,
	122,
	122,
	3,
	3,
	3,
	49,
	3,
	133,
	133,
	3,
	133,
	3,
	26,
	116,
	2158,
	2159,
	23,
	23,
	28,
	26,
	32,
	23,
	114,
	14,
	23,
	14,
	32,
	23,
	114,
	14,
	23,
	14,
	32,
	23,
	114,
	14,
	23,
	14,
	32,
	23,
	114,
	14,
	23,
	14,
	32,
	23,
	114,
	14,
	23,
	14,
	32,
	23,
	114,
	14,
	23,
	14,
	32,
	23,
	114,
	14,
	23,
	14,
	23,
	26,
	3,
	23,
	26,
	32,
	23,
	114,
	14,
	23,
	14,
	32,
	23,
	114,
	14,
	23,
	14,
	2152,
	32,
	23,
	114,
	14,
	23,
	14,
	2152,
	32,
	23,
	114,
	14,
	23,
	14,
	32,
	23,
	114,
	14,
	23,
	14,
	32,
	23,
	114,
	14,
	23,
	14,
	32,
	23,
	114,
	14,
	23,
	14,
	32,
	23,
	114,
	14,
	23,
	14,
	32,
	23,
	114,
	14,
	23,
	14,
};
extern const Il2CppCodeGenModule g_AssemblyU2DCSharpCodeGenModule;
const Il2CppCodeGenModule g_AssemblyU2DCSharpCodeGenModule = 
{
	"Assembly-CSharp.dll",
	542,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
};
