﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.Int32 UnityEngine.U2D.PixelPerfectCamera::get_assetsPPU()
extern void PixelPerfectCamera_get_assetsPPU_m4FC3DEE64A62130026A4E63F1076EAC99FE9533E (void);
// 0x00000002 System.Void UnityEngine.U2D.PixelPerfectCamera::set_assetsPPU(System.Int32)
extern void PixelPerfectCamera_set_assetsPPU_mEF65A493849F59CC052F137183C0382B332687C9 (void);
// 0x00000003 System.Int32 UnityEngine.U2D.PixelPerfectCamera::get_refResolutionX()
extern void PixelPerfectCamera_get_refResolutionX_m6BD7EAF7B74C65AFC7913C0A6092B69D7749F8DD (void);
// 0x00000004 System.Void UnityEngine.U2D.PixelPerfectCamera::set_refResolutionX(System.Int32)
extern void PixelPerfectCamera_set_refResolutionX_mDEFF2D613C8B6B3E4788A062B3FB57AE14926C26 (void);
// 0x00000005 System.Int32 UnityEngine.U2D.PixelPerfectCamera::get_refResolutionY()
extern void PixelPerfectCamera_get_refResolutionY_m9475D23352FEEA4E13B6862E2C10A6E57C5537B5 (void);
// 0x00000006 System.Void UnityEngine.U2D.PixelPerfectCamera::set_refResolutionY(System.Int32)
extern void PixelPerfectCamera_set_refResolutionY_m3025C418DFB82AE22CB2E31596C9E611A621DB42 (void);
// 0x00000007 System.Boolean UnityEngine.U2D.PixelPerfectCamera::get_upscaleRT()
extern void PixelPerfectCamera_get_upscaleRT_m6A31517879F222D89C10D38C37FB090659FC4C18 (void);
// 0x00000008 System.Void UnityEngine.U2D.PixelPerfectCamera::set_upscaleRT(System.Boolean)
extern void PixelPerfectCamera_set_upscaleRT_mBE9E7290D1F807E032E0A3B9B0FDB9838779C799 (void);
// 0x00000009 System.Boolean UnityEngine.U2D.PixelPerfectCamera::get_pixelSnapping()
extern void PixelPerfectCamera_get_pixelSnapping_m2E7FAD34761F54B06B365CE99688E3D775332ED1 (void);
// 0x0000000A System.Void UnityEngine.U2D.PixelPerfectCamera::set_pixelSnapping(System.Boolean)
extern void PixelPerfectCamera_set_pixelSnapping_m8027E5E627E90377DB736A6A84BF2326024829F2 (void);
// 0x0000000B System.Boolean UnityEngine.U2D.PixelPerfectCamera::get_cropFrameX()
extern void PixelPerfectCamera_get_cropFrameX_m82CC0C5D56DE62D12AE358B49EEAB01FFCA6D928 (void);
// 0x0000000C System.Void UnityEngine.U2D.PixelPerfectCamera::set_cropFrameX(System.Boolean)
extern void PixelPerfectCamera_set_cropFrameX_m22235D7C5B4BF09115D5C6515405F294B4E2D63F (void);
// 0x0000000D System.Boolean UnityEngine.U2D.PixelPerfectCamera::get_cropFrameY()
extern void PixelPerfectCamera_get_cropFrameY_m6D255BA5990DB47B3A40A5856F8B3F5E81FBCA61 (void);
// 0x0000000E System.Void UnityEngine.U2D.PixelPerfectCamera::set_cropFrameY(System.Boolean)
extern void PixelPerfectCamera_set_cropFrameY_mBFD5C87E1237BE970F901C2408754D20BEAD3ABD (void);
// 0x0000000F System.Boolean UnityEngine.U2D.PixelPerfectCamera::get_stretchFill()
extern void PixelPerfectCamera_get_stretchFill_m69F37FF6D2B7446EE832C51341340B7397CF3594 (void);
// 0x00000010 System.Void UnityEngine.U2D.PixelPerfectCamera::set_stretchFill(System.Boolean)
extern void PixelPerfectCamera_set_stretchFill_m704497F2F1C19BED3B715FE090D89C7471BAEDE3 (void);
// 0x00000011 System.Int32 UnityEngine.U2D.PixelPerfectCamera::get_pixelRatio()
extern void PixelPerfectCamera_get_pixelRatio_mB8D9015493938BC024186D7B42FC530DD6D8E742 (void);
// 0x00000012 UnityEngine.Vector3 UnityEngine.U2D.PixelPerfectCamera::RoundToPixel(UnityEngine.Vector3)
extern void PixelPerfectCamera_RoundToPixel_mEF146F5E93D96759CED2333D17AC0E4C9132EEE0 (void);
// 0x00000013 System.Single UnityEngine.U2D.PixelPerfectCamera::CorrectCinemachineOrthoSize(System.Single)
extern void PixelPerfectCamera_CorrectCinemachineOrthoSize_mB3FF21607A5769DC55DB79CD95C4B13225984F40 (void);
// 0x00000014 System.Void UnityEngine.U2D.PixelPerfectCamera::PixelSnap()
extern void PixelPerfectCamera_PixelSnap_m3C547EDD7DF28B9FE0CCF3A5ADE62DE186F18FBF (void);
// 0x00000015 System.Void UnityEngine.U2D.PixelPerfectCamera::Awake()
extern void PixelPerfectCamera_Awake_mBC49F0CFF5CA18668C729D066A15F2CEE0C30F80 (void);
// 0x00000016 System.Void UnityEngine.U2D.PixelPerfectCamera::LateUpdate()
extern void PixelPerfectCamera_LateUpdate_m14A8976B383944D2811FBBE3B1EB25F7CB94F2AC (void);
// 0x00000017 System.Void UnityEngine.U2D.PixelPerfectCamera::OnPreCull()
extern void PixelPerfectCamera_OnPreCull_mAB060C866035F1AE366328C1C7D3C6D7071E0DC0 (void);
// 0x00000018 System.Void UnityEngine.U2D.PixelPerfectCamera::OnPreRender()
extern void PixelPerfectCamera_OnPreRender_mE9427D6727D848DE28FC7A998FBD6CB345B7456C (void);
// 0x00000019 System.Void UnityEngine.U2D.PixelPerfectCamera::OnPostRender()
extern void PixelPerfectCamera_OnPostRender_mB6CE2D55DBD0A2D983B9F47042ECE099E447CD2B (void);
// 0x0000001A System.Void UnityEngine.U2D.PixelPerfectCamera::OnDisable()
extern void PixelPerfectCamera_OnDisable_m90E9EB8567112CDA6855011A418AB06932BBF95D (void);
// 0x0000001B System.Void UnityEngine.U2D.PixelPerfectCamera::.ctor()
extern void PixelPerfectCamera__ctor_m0C6910402A66B0B617D80D1ACBA70FF744F5593E (void);
// 0x0000001C System.Int32 UnityEngine.U2D.IPixelPerfectCamera::get_assetsPPU()
// 0x0000001D System.Int32 UnityEngine.U2D.IPixelPerfectCamera::get_refResolutionX()
// 0x0000001E System.Int32 UnityEngine.U2D.IPixelPerfectCamera::get_refResolutionY()
// 0x0000001F System.Boolean UnityEngine.U2D.IPixelPerfectCamera::get_upscaleRT()
// 0x00000020 System.Boolean UnityEngine.U2D.IPixelPerfectCamera::get_pixelSnapping()
// 0x00000021 System.Boolean UnityEngine.U2D.IPixelPerfectCamera::get_cropFrameX()
// 0x00000022 System.Boolean UnityEngine.U2D.IPixelPerfectCamera::get_cropFrameY()
// 0x00000023 System.Boolean UnityEngine.U2D.IPixelPerfectCamera::get_stretchFill()
// 0x00000024 System.Void UnityEngine.U2D.PixelPerfectCameraInternal::.ctor(UnityEngine.U2D.IPixelPerfectCamera)
extern void PixelPerfectCameraInternal__ctor_m43EDD824545ABC194AA70BC5EC97C43E3919BF07 (void);
// 0x00000025 System.Void UnityEngine.U2D.PixelPerfectCameraInternal::OnBeforeSerialize()
extern void PixelPerfectCameraInternal_OnBeforeSerialize_mDA3112724BC91749DCF1C2C50D85D491DDBB728A (void);
// 0x00000026 System.Void UnityEngine.U2D.PixelPerfectCameraInternal::OnAfterDeserialize()
extern void PixelPerfectCameraInternal_OnAfterDeserialize_mD746360187E14C80C0B39728160738EBD1375AD6 (void);
// 0x00000027 System.Void UnityEngine.U2D.PixelPerfectCameraInternal::CalculateCameraProperties(System.Int32,System.Int32)
extern void PixelPerfectCameraInternal_CalculateCameraProperties_m3759DC708ADAE35AC4B9836FD4B9E2B864F567D1 (void);
// 0x00000028 UnityEngine.Rect UnityEngine.U2D.PixelPerfectCameraInternal::CalculatePostRenderPixelRect(System.Single,System.Int32,System.Int32)
extern void PixelPerfectCameraInternal_CalculatePostRenderPixelRect_mC08294BBF9CB3586547D1B9817F0EBD0FD3DFDE7 (void);
// 0x00000029 System.Single UnityEngine.U2D.PixelPerfectCameraInternal::CorrectCinemachineOrthoSize(System.Single)
extern void PixelPerfectCameraInternal_CorrectCinemachineOrthoSize_m91D310AF8441B649A9C654E4CCF3948151FF8674 (void);
static Il2CppMethodPointer s_methodPointers[41] = 
{
	PixelPerfectCamera_get_assetsPPU_m4FC3DEE64A62130026A4E63F1076EAC99FE9533E,
	PixelPerfectCamera_set_assetsPPU_mEF65A493849F59CC052F137183C0382B332687C9,
	PixelPerfectCamera_get_refResolutionX_m6BD7EAF7B74C65AFC7913C0A6092B69D7749F8DD,
	PixelPerfectCamera_set_refResolutionX_mDEFF2D613C8B6B3E4788A062B3FB57AE14926C26,
	PixelPerfectCamera_get_refResolutionY_m9475D23352FEEA4E13B6862E2C10A6E57C5537B5,
	PixelPerfectCamera_set_refResolutionY_m3025C418DFB82AE22CB2E31596C9E611A621DB42,
	PixelPerfectCamera_get_upscaleRT_m6A31517879F222D89C10D38C37FB090659FC4C18,
	PixelPerfectCamera_set_upscaleRT_mBE9E7290D1F807E032E0A3B9B0FDB9838779C799,
	PixelPerfectCamera_get_pixelSnapping_m2E7FAD34761F54B06B365CE99688E3D775332ED1,
	PixelPerfectCamera_set_pixelSnapping_m8027E5E627E90377DB736A6A84BF2326024829F2,
	PixelPerfectCamera_get_cropFrameX_m82CC0C5D56DE62D12AE358B49EEAB01FFCA6D928,
	PixelPerfectCamera_set_cropFrameX_m22235D7C5B4BF09115D5C6515405F294B4E2D63F,
	PixelPerfectCamera_get_cropFrameY_m6D255BA5990DB47B3A40A5856F8B3F5E81FBCA61,
	PixelPerfectCamera_set_cropFrameY_mBFD5C87E1237BE970F901C2408754D20BEAD3ABD,
	PixelPerfectCamera_get_stretchFill_m69F37FF6D2B7446EE832C51341340B7397CF3594,
	PixelPerfectCamera_set_stretchFill_m704497F2F1C19BED3B715FE090D89C7471BAEDE3,
	PixelPerfectCamera_get_pixelRatio_mB8D9015493938BC024186D7B42FC530DD6D8E742,
	PixelPerfectCamera_RoundToPixel_mEF146F5E93D96759CED2333D17AC0E4C9132EEE0,
	PixelPerfectCamera_CorrectCinemachineOrthoSize_mB3FF21607A5769DC55DB79CD95C4B13225984F40,
	PixelPerfectCamera_PixelSnap_m3C547EDD7DF28B9FE0CCF3A5ADE62DE186F18FBF,
	PixelPerfectCamera_Awake_mBC49F0CFF5CA18668C729D066A15F2CEE0C30F80,
	PixelPerfectCamera_LateUpdate_m14A8976B383944D2811FBBE3B1EB25F7CB94F2AC,
	PixelPerfectCamera_OnPreCull_mAB060C866035F1AE366328C1C7D3C6D7071E0DC0,
	PixelPerfectCamera_OnPreRender_mE9427D6727D848DE28FC7A998FBD6CB345B7456C,
	PixelPerfectCamera_OnPostRender_mB6CE2D55DBD0A2D983B9F47042ECE099E447CD2B,
	PixelPerfectCamera_OnDisable_m90E9EB8567112CDA6855011A418AB06932BBF95D,
	PixelPerfectCamera__ctor_m0C6910402A66B0B617D80D1ACBA70FF744F5593E,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	PixelPerfectCameraInternal__ctor_m43EDD824545ABC194AA70BC5EC97C43E3919BF07,
	PixelPerfectCameraInternal_OnBeforeSerialize_mDA3112724BC91749DCF1C2C50D85D491DDBB728A,
	PixelPerfectCameraInternal_OnAfterDeserialize_mD746360187E14C80C0B39728160738EBD1375AD6,
	PixelPerfectCameraInternal_CalculateCameraProperties_m3759DC708ADAE35AC4B9836FD4B9E2B864F567D1,
	PixelPerfectCameraInternal_CalculatePostRenderPixelRect_mC08294BBF9CB3586547D1B9817F0EBD0FD3DFDE7,
	PixelPerfectCameraInternal_CorrectCinemachineOrthoSize_m91D310AF8441B649A9C654E4CCF3948151FF8674,
};
static const int32_t s_InvokerIndices[41] = 
{
	10,
	32,
	10,
	32,
	10,
	32,
	114,
	31,
	114,
	31,
	114,
	31,
	114,
	31,
	114,
	31,
	10,
	1105,
	1094,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	10,
	10,
	10,
	114,
	114,
	114,
	114,
	114,
	26,
	23,
	23,
	169,
	1596,
	1094,
};
extern const Il2CppCodeGenModule g_Unity_2D_PixelPerfectCodeGenModule;
const Il2CppCodeGenModule g_Unity_2D_PixelPerfectCodeGenModule = 
{
	"Unity.2D.PixelPerfect.dll",
	41,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
};
