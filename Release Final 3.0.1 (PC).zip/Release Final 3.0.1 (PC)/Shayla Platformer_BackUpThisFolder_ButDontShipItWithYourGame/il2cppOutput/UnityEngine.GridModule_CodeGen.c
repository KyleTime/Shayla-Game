﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 UnityEngine.Vector3 UnityEngine.GridLayout::CellToLocalInterpolated(UnityEngine.Vector3)
extern void GridLayout_CellToLocalInterpolated_m7F44E7F9CEE03E76CD5B2E0567F53036AC784CD2 (void);
// 0x00000002 System.Void UnityEngine.GridLayout::DoNothing()
extern void GridLayout_DoNothing_m0ED53398C0D9944BB9666DD66AD9940DE931A54C (void);
// 0x00000003 System.Void UnityEngine.GridLayout::CellToLocalInterpolated_Injected(UnityEngine.Vector3&,UnityEngine.Vector3&)
extern void GridLayout_CellToLocalInterpolated_Injected_m9937AFA062E97FFEBC7E223E17AD50185D1D597E (void);
static Il2CppMethodPointer s_methodPointers[3] = 
{
	GridLayout_CellToLocalInterpolated_m7F44E7F9CEE03E76CD5B2E0567F53036AC784CD2,
	GridLayout_DoNothing_m0ED53398C0D9944BB9666DD66AD9940DE931A54C,
	GridLayout_CellToLocalInterpolated_Injected_m9937AFA062E97FFEBC7E223E17AD50185D1D597E,
};
static const int32_t s_InvokerIndices[3] = 
{
	1105,
	23,
	522,
};
extern const Il2CppCodeGenModule g_UnityEngine_GridModuleCodeGenModule;
const Il2CppCodeGenModule g_UnityEngine_GridModuleCodeGenModule = 
{
	"UnityEngine.GridModule.dll",
	3,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
};
